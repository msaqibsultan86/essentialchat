package studio.spark.essentialchat.mixin;

import net.minecraft.client.gui.hud.ChatHud;
import net.minecraft.client.gui.hud.ChatHudLine;
import net.minecraft.client.gui.hud.MessageIndicator;
import net.minecraft.network.message.MessageSignatureData;
import net.minecraft.text.MutableText;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import studio.spark.essentialchat.client.EssentialChatClient;

import java.util.List;

/**
 * Merges consecutive identical chat messages into a single line with a "(count)"
 * suffix, vanilla-style. Wrapped in try/catch so any failure simply falls back to
 * normal chat behaviour instead of crashing.
 */
@Mixin(ChatHud.class)
public abstract class ChatStackMixin {

    @Shadow @Final private List<ChatHudLine> messages;
    @Shadow public abstract void addMessage(Text message);
    @Shadow public abstract void refresh();

    @Unique private String essential$lastRaw = null;
    @Unique private int essential$count = 1;
    @Unique private boolean essential$busy = false;

    @Inject(method = "addMessage(Lnet/minecraft/text/Text;Lnet/minecraft/network/message/MessageSignatureData;Lnet/minecraft/client/gui/hud/MessageIndicator;)V",
            at = @At("HEAD"), cancellable = true)
    private void essential$stack(Text message, MessageSignatureData sig, MessageIndicator ind, CallbackInfo ci) {
        if (essential$busy) return;   // ignore our own re-added merged line
        if (EssentialChatClient.config == null || !EssentialChatClient.config.stackMessages) return;

        try {
            String raw = message.getString();
            if (raw != null && raw.equals(essential$lastRaw) && !messages.isEmpty()) {
                essential$count++;
                messages.remove(0);   // drop the previous copy of this line
                MutableText stacked = Text.literal(raw + " ")
                        .append(Text.literal("(" + essential$count + ")").formatted(Formatting.GRAY));
                essential$busy = true;
                this.addMessage(stacked);
                this.refresh();       // rebuild wrapped visible lines
                essential$busy = false;
                ci.cancel();          // cancel the duplicate add
            } else {
                essential$lastRaw = raw;
                essential$count = 1;
            }
        } catch (Throwable t) {
            essential$busy = false;   // safety: never crash, just fall back to normal
        }
    }
}
