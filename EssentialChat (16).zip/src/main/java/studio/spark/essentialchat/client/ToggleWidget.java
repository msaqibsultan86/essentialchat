package studio.spark.essentialchat.client;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.narration.NarrationMessageBuilder;
import net.minecraft.client.gui.widget.PressableWidget;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

import java.util.function.BooleanSupplier;

/** Toggle row on a light inventory panel: inset slot + dark label + blue square switch. */
public class ToggleWidget extends PressableWidget {

    private final BooleanSupplier getter;
    private final Runnable onToggle;
    private final String name;
    private final Identifier icon;
    private float knob = -1f;
    private float hover = 0f;

    private static final int TRACK_W = 28, TRACK_H = 14, KNOB = 10;

    public ToggleWidget(int x, int y, int w, int h, String name, Identifier icon,
                        BooleanSupplier getter, Runnable onToggle) {
        super(x, y, w, h, Text.literal(name));
        this.name = name; this.icon = icon; this.getter = getter; this.onToggle = onToggle;
    }

    @Override
    public void onPress() {
        onToggle.run();
        MinecraftClient.getInstance().getSoundManager()
                .play(PositionedSoundInstance.master(SoundEvents.UI_BUTTON_CLICK, 1.0f));
    }

    @Override
    protected void renderWidget(DrawContext ctx, int mouseX, int mouseY, float delta) {
        boolean on = getter.getAsBoolean();
        if (knob < 0f) knob = on ? 1f : 0f;
        knob += ((on ? 1f : 0f) - knob) * 0.3f;
        hover += ((this.isHovered() ? 1f : 0f) - hover) * 0.25f;

        int x1 = getX(), y1 = getY(), x2 = getX() + getWidth(), y2 = getY() + getHeight();
        var tr = MinecraftClient.getInstance().textRenderer;

        // inset inventory slot (darker grey, beveled inward)
        int slot = lerp(0xFF8B8B8B, 0xFF9A9A9A, hover);
        ctx.fill(x1, y1, x2, y2, slot);
        ctx.fill(x1, y1, x2, y1 + 1, 0xFF555555);       // inset top shadow
        ctx.fill(x1, y1, x1 + 1, y2, 0xFF555555);       // inset left shadow
        ctx.fill(x1, y2 - 1, x2, y2, 0xFFDDDDDD);       // inset bottom light
        ctx.fill(x2 - 1, y1, x2, y2, 0xFFDDDDDD);       // inset right light

        // icon + dark label (readable on grey)
        int textX = x1 + 7;
        if (icon != null) {
            int sz = 12;
            ctx.drawTexture(icon, x1 + 6, y1 + (getHeight() - sz) / 2, sz, sz, 0, 0, 32, 32, 32, 32);
            textX = x1 + 6 + sz + 5;
        }
        ctx.drawText(tr, Text.literal(name), textX, y1 + (getHeight() - 8) / 2, 0xFF2A2A2A, false);

        // clean ON/OFF switch — green when enabled, grey when disabled (MC-style)
        int trackX = x2 - TRACK_W - 6;
        int trackY = y1 + (getHeight() - TRACK_H) / 2;
        int track = lerp(0xFF707070, 0xFF43C04A, knob);          // grey -> green
        ctx.fill(trackX - 1, trackY - 1, trackX + TRACK_W + 1, trackY + TRACK_H + 1, 0xFF262626); // outline
        ctx.fill(trackX, trackY, trackX + TRACK_W, trackY + TRACK_H, track);
        ctx.fill(trackX, trackY, trackX + TRACK_W, trackY + 1, 0x40FFFFFF);   // top sheen

        int knobX = trackX + 2 + (int) (knob * (TRACK_W - KNOB - 4));
        int knobY = trackY + 2;
        ctx.fill(knobX - 1, knobY - 1, knobX + KNOB + 1, knobY + KNOB + 1, 0xFF262626); // knob outline
        ctx.fill(knobX, knobY, knobX + KNOB, knobY + KNOB, 0xFFF7FAFF);
        ctx.fill(knobX, knobY, knobX + KNOB, knobY + 1, 0xFFFFFFFF);          // knob highlight
    }

    @Override
    protected void appendClickableNarrations(NarrationMessageBuilder b) { appendDefaultNarrations(b); }

    private static int lerp(int a, int b, float t) {
        t = Math.max(0f, Math.min(1f, t));
        int ar=(a>>16)&0xFF, ag=(a>>8)&0xFF, ab=a&0xFF;
        int br=(b>>16)&0xFF, bg=(b>>8)&0xFF, bb=b&0xFF;
        return 0xFF000000 | ((int)(ar+(br-ar)*t)<<16) | ((int)(ag+(bg-ag)*t)<<8) | (int)(ab+(bb-ab)*t);
    }
}
