package studio.spark.essentialchat.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.message.v1.ClientReceiveMessageEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.text.MutableText;
import net.minecraft.text.Style;
import net.minecraft.text.TextColor;
import net.minecraft.util.Formatting;
import org.lwjgl.glfw.GLFW;

public class EssentialChatClient implements ClientModInitializer {

    public static EssentialConfig config;
    public static String lastMessage = "";   // captured for "copy last message"

    private static KeyBinding openMenu;
    private static KeyBinding toggleHud;
    private static KeyBinding clearChat;
    private static KeyBinding copyLastMsg;
    private static KeyBinding copyCoords;

    @Override
    public void onInitializeClient() {
        config = EssentialConfig.load();

        // --- keybinds (all rebindable in Controls) ---
        openMenu    = reg("open_menu",     GLFW.GLFW_KEY_O);
        toggleHud   = reg("toggle_hud",    GLFW.GLFW_KEY_H);
        clearChat   = reg("clear_chat",    GLFW.GLFW_KEY_DELETE);
        copyLastMsg = reg("copy_last_msg", GLFW.GLFW_KEY_N);
        copyCoords  = reg("copy_coords",   GLFW.GLFW_KEY_J);

        // --- capture incoming messages (for highlight + copy last) ---
        ClientReceiveMessageEvents.ALLOW_GAME.register((message, overlay) -> {
            if (!overlay) handleIncoming(message);
            return true;
        });
        ClientReceiveMessageEvents.ALLOW_CHAT.register((message, signed, sender, params, ts) -> {
            handleIncoming(message);
            return true;
        });

        // --- HUD overlay ---
        HudOverlay.register();
        ArmorHud.register();

        // --- buttons in ESC menu + chat screen ---
        ScreenInjector.register();

        // --- key handling ---
        ClientTickEvents.END_CLIENT_TICK.register(this::onTick);
    }

    private static KeyBinding reg(String name, int key) {
        return KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.essentialchat." + name, InputUtil.Type.KEYSYM, key, "category.essentialchat"));
    }

    private void handleIncoming(Text message) {
        if (message == null) return;
        String text = message.getString();
        lastMessage = text;

        MinecraftClient mc = MinecraftClient.getInstance();
        if (config.chatHighlight && mc.player != null) {
            String myName = mc.player.getGameProfile().getName();
            if (myName == null || myName.isEmpty()) return;
            String lower = text.toLowerCase();
            String my = myName.toLowerCase();

            // skip your OWN chat message: "<myName> ..."
            if (lower.startsWith("<" + my + ">")) return;
            // skip system messages that lead with your name (death, join/leave, advancements)
            if (lower.startsWith(my)) return;
            // otherwise, if someone else's message contains your name -> real mention
            if (lower.contains(my)) {
                onMentioned(mc, text);
            }
        }
    }

    /** Fires when your name is mentioned: soft sound + clean gradient title. */
    private void onMentioned(MinecraftClient mc, String text) {
        // 1) soft sound
        mc.player.playSound(SoundEvents.ENTITY_EXPERIENCE_ORB_PICKUP, 0.7f, 1.3f);

        // 2) clean black->gray gradient title + small subtitle
        if (mc.inGameHud != null) {
            mc.inGameHud.setTitle(gradient("MENTIONED", 0x2B2B2B, 0xC0C0C0));
            mc.inGameHud.setSubtitle(Text.literal("you were mentioned")
                    .setStyle(Style.EMPTY.withColor(TextColor.fromRgb(0x9A9A9A))));
            mc.inGameHud.setTitleTicks(3, 30, 8);   // quick, clean flash
        }
    }

    /** Builds a per-letter black->gray gradient title. */
    private static MutableText gradient(String s, int from, int to) {
        MutableText out = Text.empty();
        int n = s.length();
        for (int i = 0; i < n; i++) {
            float f = n <= 1 ? 0f : (float) i / (n - 1);
            int col = lerpColor(from, to, f);
            out.append(Text.literal(String.valueOf(s.charAt(i)))
                    .setStyle(Style.EMPTY.withColor(TextColor.fromRgb(col)).withBold(true)));
        }
        return out;
    }

    private static int lerpColor(int a, int b, float t) {
        t = Math.max(0f, Math.min(1f, t));
        int ar=(a>>16)&0xFF, ag=(a>>8)&0xFF, ab=a&0xFF;
        int br=(b>>16)&0xFF, bg=(b>>8)&0xFF, bb=b&0xFF;
        return ((int)(ar+(br-ar)*t)<<16) | ((int)(ag+(bg-ag)*t)<<8) | (int)(ab+(bb-ab)*t);
    }


    private void onTick(MinecraftClient mc) {
        if (mc.player == null) return;

        while (openMenu.wasPressed()) {
            mc.setScreen(new EssentialChatScreen());
        }
        while (toggleHud.wasPressed()) {
            config.hudEnabled = !config.hudEnabled;
            config.save();
            msg(mc, "HUD " + (config.hudEnabled ? "§aon" : "§coff"));
        }
        while (clearChat.wasPressed()) {
            mc.inGameHud.getChatHud().clear(false);
        }
        while (copyLastMsg.wasPressed()) {
            if (!lastMessage.isEmpty()) {
                mc.keyboard.setClipboard(lastMessage);
                msg(mc, "§aCopied last message");
            }
        }
        while (copyCoords.wasPressed()) {
            String c = String.format("%.0f %.0f %.0f",
                    mc.player.getX(), mc.player.getY(), mc.player.getZ());
            mc.keyboard.setClipboard(c);
            msg(mc, "§aCopied coords: §f" + c);
        }
    }

    private void msg(MinecraftClient mc, String s) {
        if (mc.player != null) {
            // bold branded prefix: white ESSENTIAL + blue CHAT (matches logo)
            mc.player.sendMessage(Text.literal("§f§lESSENTIAL §9§lCHAT §8§l> §r" + s), false);
        }
    }
}
