package studio.spark.essentialchat.client;

import java.util.ArrayDeque;
import java.util.Deque;

/** Tracks left/right clicks in the last second for a CPS counter. */
public class CpsTracker {

    private static final Deque<Long> LEFT = new ArrayDeque<>();
    private static final Deque<Long> RIGHT = new ArrayDeque<>();

    public static void leftClick()  { LEFT.add(System.currentTimeMillis()); }
    public static void rightClick() { RIGHT.add(System.currentTimeMillis()); }

    public static int leftCps()  { return countRecent(LEFT); }
    public static int rightCps() { return countRecent(RIGHT); }

    private static int countRecent(Deque<Long> q) {
        long now = System.currentTimeMillis();
        while (!q.isEmpty() && now - q.peekFirst() > 1000) q.pollFirst();
        return q.size();
    }
}
