package studio.spark.essentialchat.client;

import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.client.screen.v1.Screens;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.client.gui.screen.GameMenuScreen;
import net.minecraft.util.Identifier;

/** Adds Essential Chat buttons to the pause menu and chat screen. */
public class ScreenInjector {

    public static void register() {
        ScreenEvents.AFTER_INIT.register((client, screen, scaledWidth, scaledHeight) -> {
            if (screen instanceof GameMenuScreen) {
                int bw = 204, bh = 20;
                int bx = (scaledWidth - bw) / 2;
                int by = scaledHeight - 24;   // fallback

                // anchor directly below the "Save and Quit" / "Disconnect" button
                for (var w : Screens.getButtons(screen)) {
                    if (w instanceof net.minecraft.client.gui.widget.ClickableWidget cw) {
                        String msg = cw.getMessage().getString().toLowerCase();
                        if (msg.contains("title") || msg.contains("disconnect")
                                || msg.contains("quit") || msg.contains("main menu")) {
                            bx = cw.getX();
                            bw = cw.getWidth();
                            by = cw.getY() + cw.getHeight() + 4;
                        }
                    }
                }

                Screens.getButtons(screen).add(new CleanButton(
                        bx, by, bw, bh, "Essential Chat",
                        () -> client.setScreen(new EssentialChatScreen())));
            } else if (screen instanceof ChatScreen) {
                // clear chat button, top-right (the spot you circled)
                Screens.getButtons(screen).add(new CleanButton(
                        scaledWidth - 88, 6, 80, 16, "Clear",
                        () -> {
                            MinecraftClient mc = MinecraftClient.getInstance();
                            if (mc.inGameHud != null) mc.inGameHud.getChatHud().clear(false);
                        }).icon(Identifier.of("essentialchat", "textures/gui/icons/clearchat.png")));
            }
        });
    }
}
