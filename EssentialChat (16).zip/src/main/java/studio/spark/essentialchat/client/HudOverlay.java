package studio.spark.essentialchat.client;

import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

public class HudOverlay {

    private static final SimpleDateFormat CLOCK = new SimpleDateFormat("HH:mm:ss");

    // ---- icons (add more here as you supply them) ----
    private static final Identifier ICON_GLOBE =
            Identifier.of("essentialchat", "textures/gui/icons/globe.png");
    private static final Identifier ICON_PING =
            Identifier.of("essentialchat", "textures/gui/icons/ping.png");
    private static final Identifier ICON_MCCLOCK =
            Identifier.of("essentialchat", "textures/gui/icons/mcclock.png");
    private static final Identifier ICON_BIOME =
            Identifier.of("essentialchat", "textures/gui/icons/biome.png");
    private static final Identifier ICON_REALCLOCK =
            Identifier.of("essentialchat", "textures/gui/icons/realclock.png");
    private static final Identifier ICON_FPS =
            Identifier.of("essentialchat", "textures/gui/icons/fps.png");
    private static final Identifier ICON_DIRECTION =
            Identifier.of("essentialchat", "textures/gui/icons/direction.png");
    private static final Identifier ICON_DAY =
            Identifier.of("essentialchat", "textures/gui/icons/day.png");
    private static final Identifier ICON_CPS =
            Identifier.of("essentialchat", "textures/gui/icons/cps.png");
    private static final Identifier ICON_ARMOR =
            Identifier.of("essentialchat", "textures/gui/icons/armor.png");
    private static final Identifier ICON_SPEED =
            Identifier.of("essentialchat", "textures/gui/icons/speed.png");
    private static final Identifier ICON_HELDDURA =
            Identifier.of("essentialchat", "textures/gui/icons/helddura.png");

    // speed tracking
    private static double lastX, lastZ;
    private static long lastSpeedTime;
    private static double speedBps;

    public static void register() {
        HudRenderCallback.EVENT.register(HudOverlay::onRender);
    }

    private static void onRender(DrawContext ctx, RenderTickCounter tick) {
        MinecraftClient mc = MinecraftClient.getInstance();
        EssentialConfig cfg = EssentialChatClient.config;
        if (cfg == null || !cfg.hudEnabled) return;
        if (mc.player == null || mc.options.hudHidden) return;

        var tr = mc.textRenderer;
        List<Identifier> icons = new ArrayList<>();
        List<String> texts = new ArrayList<>();

        if (cfg.showClock) { icons.add(ICON_REALCLOCK); texts.add("§f" + CLOCK.format(new Date())); }

        if (cfg.showGameTime && mc.world != null) {
            long t = mc.world.getTimeOfDay() % 24000L;
            int hour = (int) (((t / 1000) + 6) % 24);
            int min = (int) ((t % 1000) * 60 / 1000);
            icons.add(ICON_MCCLOCK); texts.add(String.format("§f%02d:%02d §7%s", hour, min, phase((int) t)));
        }
        if (cfg.showFps) {
            int fps = mc.getCurrentFps();
            icons.add(ICON_FPS); texts.add("§7FPS: " + fpsColor(fps) + fps);
        }
        if (cfg.showCoords) {
            icons.add(ICON_GLOBE);   // globe icon on coords
            texts.add(String.format("§fx: §b%.0f§f, z: §b%.0f§f, y: §b%.0f",
                    mc.player.getX(), mc.player.getZ(), mc.player.getY()));
        }
        if (cfg.showBiome && mc.world != null) {
            String biome = biomeName(mc);
            if (!biome.isEmpty()) { icons.add(ICON_BIOME); texts.add("§7" + biome); }
        }
        if (cfg.showPing) {
            int ping = 0;
            if (mc.getNetworkHandler() != null) {
                PlayerListEntry e = mc.getNetworkHandler().getPlayerListEntry(mc.player.getUuid());
                if (e != null) ping = e.getLatency();
            }
            icons.add(ICON_PING); texts.add("§7Ping: " + pingColor(ping) + ping + " ms");
        }
        if (cfg.showDirection) {
            icons.add(ICON_DIRECTION); texts.add("§7Facing: §f" + facing(mc));
        }
        if (cfg.showDay && mc.world != null) {
            long day = mc.world.getTimeOfDay() / 24000L + 1;
            icons.add(ICON_DAY); texts.add("§7Day §f" + day);
        }
        if (cfg.showCps) {
            icons.add(ICON_CPS);
            texts.add("§7CPS: §f" + CpsTracker.leftCps() + " §8| §f" + CpsTracker.rightCps());
        }
        if (cfg.showArmor) {
            int pct = armorPct(mc);
            icons.add(ICON_ARMOR); texts.add("§7Armor: " + duraColor(pct) + pct + "%");
        }
        if (cfg.showSpeed) {
            updateSpeed(mc);
            icons.add(ICON_SPEED); texts.add(String.format("§7Speed: §f%.1f §7b/s", speedBps));
        }
        if (cfg.showHeldDura) {
            int pct = heldDuraPct(mc);
            if (pct >= 0) { icons.add(ICON_HELDDURA); texts.add("§7Item: " + duraColor(pct) + pct + "%"); }
        }
        if (texts.isEmpty()) return;

        int pad = 5, lineH = 12, iconCol = 12, iconSz = 9;
        int maxW = 0;
        for (String s : texts) maxW = Math.max(maxW, tr.getWidth(s));

        int bx = 4, by = 4;
        int bw = iconCol + maxW + pad * 2;
        int bh = texts.size() * lineH + pad * 2 - 2;

        ctx.fill(bx, by, bx + bw, by + bh, 0x90000000);
        ctx.fill(bx, by, bx + 2, by + bh, 0xFF3BA9FF);

        int ty = by + pad;
        int textX = bx + pad + iconCol;
        for (int i = 0; i < texts.size(); i++) {
            Identifier ic = icons.get(i);
            if (ic != null) {
                ctx.drawTexture(ic, bx + pad, ty - 1, iconSz, iconSz, 0, 0, 32, 32, 32, 32);
            }
            ctx.drawTextWithShadow(tr, Text.literal(texts.get(i)), textX, ty, 0xFFFFFFFF);
            ty += lineH;
        }
    }

    private static String phase(int t) {
        if (t < 12000) return "Daytime";
        if (t < 13800) return "Sunset";
        if (t < 22200) return "Night";
        return "Sunrise";
    }

    private static String biomeName(MinecraftClient mc) {
        try {
            var entry = mc.world.getBiome(mc.player.getBlockPos());
            Optional<?> keyOpt = entry.getKey();
            if (keyOpt.isPresent()) {
                String path = keyOpt.get().toString();
                int idx = path.lastIndexOf('/');
                if (idx >= 0) path = path.substring(idx + 1);
                path = path.replace("]", "");
                return pretty(path);
            }
        } catch (Exception ignored) {}
        return "";
    }

    private static String pretty(String s) {
        String[] parts = s.split("_");
        StringBuilder b = new StringBuilder();
        for (String p : parts) {
            if (p.isEmpty()) continue;
            b.append(Character.toUpperCase(p.charAt(0))).append(p.substring(1)).append(" ");
        }
        return b.toString().trim();
    }

    private static String fpsColor(int fps) { return fps >= 60 ? "§a" : fps >= 30 ? "§e" : "§c"; }
    private static String pingColor(int p) { return p <= 0 ? "§7" : p < 60 ? "§a" : p < 150 ? "§e" : "§c"; }

    private static String facing(MinecraftClient mc) {
        switch (mc.player.getHorizontalFacing()) {
            case NORTH: return "N (-Z)";
            case SOUTH: return "S (+Z)";
            case EAST:  return "E (+X)";
            case WEST:  return "W (-X)";
            default:    return "?";
        }
    }

    private static int armorPct(MinecraftClient mc) {
        int max = 0, cur = 0;
        try {
            for (var s : mc.player.getInventory().armor) {
                if (s != null && !s.isEmpty() && s.isDamageable()) {
                    max += s.getMaxDamage();
                    cur += (s.getMaxDamage() - s.getDamage());
                }
            }
        } catch (Exception ignored) {}
        return max > 0 ? cur * 100 / max : 0;
    }

    private static int heldDuraPct(MinecraftClient mc) {
        try {
            var s = mc.player.getMainHandStack();
            if (s != null && !s.isEmpty() && s.isDamageable()) {
                return (s.getMaxDamage() - s.getDamage()) * 100 / s.getMaxDamage();
            }
        } catch (Exception ignored) {}
        return -1;
    }

    private static void updateSpeed(MinecraftClient mc) {
        long now = System.currentTimeMillis();
        double x = mc.player.getX(), z = mc.player.getZ();
        if (lastSpeedTime != 0) {
            double dt = (now - lastSpeedTime) / 1000.0;
            if (dt > 0.05) {
                double dx = x - lastX, dz = z - lastZ;
                speedBps = Math.sqrt(dx * dx + dz * dz) / dt;
                lastX = x; lastZ = z; lastSpeedTime = now;
            }
        } else {
            lastX = x; lastZ = z; lastSpeedTime = now;
        }
    }

    private static String duraColor(int pct) { return pct >= 60 ? "§a" : pct >= 25 ? "§e" : "§c"; }
}
