package studio.spark.essentialchat.client;

import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.item.ItemStack;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.Identifier;

/**
 * Shows the 4 armor pieces in inventory-style slots to the left of the hotbar,
 * each with the vanilla green durability bar. Warns (icon + sound) below 10%.
 */
public class ArmorHud {

    private static final Identifier WARN =
            Identifier.of("essentialchat", "textures/gui/icons/warning.png");

    private static long lastWarnSound = 0;

    public static void register() {
        HudRenderCallback.EVENT.register((ctx, tickDelta) -> {
            try { render(ctx); } catch (Throwable ignored) {}
        });
    }

    private static void render(DrawContext ctx) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.options.hudHidden) return;
        if (EssentialChatClient.config == null || !EssentialChatClient.config.armorHud) return;
        if (mc.player.isSpectator()) return;

        int sw = mc.getWindow().getScaledWidth();
        int sh = mc.getWindow().getScaledHeight();

        int slot = 20;                          // slot size
        int hotbarLeft = sw / 2 - 91;
        int x = hotbarLeft - slot - 4;          // column just left of hotbar
        int baseY = sh - slot - 2;              // bottom slot aligns with hotbar

        boolean anyLow = false;

        // helmet(3) top -> boots(0) bottom
        for (int s = 3; s >= 0; s--) {
            int row = 3 - s;
            int sx = x;
            int sy = baseY - row * (slot + 2);

            // --- inventory-style slot (dark, beveled) ---
            ctx.fill(sx, sy, sx + slot, sy + slot, 0xFF8B8B8B);        // slot border (grey)
            ctx.fill(sx + 1, sy + 1, sx + slot - 1, sy + slot - 1, 0xC0000000); // dark inset
            ctx.fill(sx + 1, sy + 1, sx + slot - 1, sy + 2, 0xFF373737);        // top shadow
            ctx.fill(sx + 1, sy + 1, sx + 2, sy + slot - 1, 0xFF373737);        // left shadow

            ItemStack stack;
            try { stack = mc.player.getInventory().armor.get(s); }
            catch (Exception e) { continue; }

            if (stack == null || stack.isEmpty()) continue;

            int ix = sx + 2, iy = sy + 2;
            ctx.drawItem(stack, ix, iy);                       // armor piece
            ctx.drawItemInSlot(mc.textRenderer, stack, ix, iy); // vanilla durability bar + count

            if (stack.isDamageable()) {
                int pct = (stack.getMaxDamage() - stack.getDamage()) * 100 / stack.getMaxDamage();
                if (pct < 10) {
                    anyLow = true;
                    if ((System.currentTimeMillis() / 400) % 2 == 0) {
                        ctx.drawTexture(WARN, sx + slot - 8, sy - 2, 10, 10, 0, 0, 32, 32, 32, 32);
                    }
                }
            }
        }

        if (anyLow) {
            long now = System.currentTimeMillis();
            if (now - lastWarnSound > 3000) {
                mc.player.playSound(SoundEvents.BLOCK_NOTE_BLOCK_PLING.value(), 0.6f, 0.5f);
                lastWarnSound = now;
            }
        }
    }
}
