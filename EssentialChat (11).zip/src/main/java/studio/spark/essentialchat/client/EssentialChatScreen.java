package studio.spark.essentialchat.client;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

public class EssentialChatScreen extends Screen {

    private static final String B = "essentialchat";
    private static final Identifier I_REALCLOCK = Identifier.of(B, "textures/gui/icons/realclock.png");
    private static final Identifier I_MCCLOCK   = Identifier.of(B, "textures/gui/icons/mcclock.png");
    private static final Identifier I_FPS       = Identifier.of(B, "textures/gui/icons/fps.png");
    private static final Identifier I_GLOBE     = Identifier.of(B, "textures/gui/icons/globe.png");
    private static final Identifier I_BIOME     = Identifier.of(B, "textures/gui/icons/biome.png");
    private static final Identifier I_PING      = Identifier.of(B, "textures/gui/icons/ping.png");
    private static final Identifier I_HIGHLIGHT = Identifier.of(B, "textures/gui/icons/highlight.png");
    private static final Identifier I_ANIM      = Identifier.of(B, "textures/gui/icons/animation.png");
    private static final Identifier I_WARN      = Identifier.of(B, "textures/gui/icons/warning.png");
    private static final Identifier I_DIR       = Identifier.of(B, "textures/gui/icons/direction.png");
    private static final Identifier I_DAY       = Identifier.of(B, "textures/gui/icons/day.png");
    private static final Identifier I_CPS       = Identifier.of(B, "textures/gui/icons/cps.png");
    private static final Identifier I_ARMOR     = Identifier.of(B, "textures/gui/icons/armor.png");
    private static final Identifier I_SPEED     = Identifier.of(B, "textures/gui/icons/speed.png");
    private static final Identifier I_HELD      = Identifier.of(B, "textures/gui/icons/helddura.png");

    private int panelX, panelY, panelW, panelH;

    public EssentialChatScreen() { super(Text.literal("Essential Chat")); }

    @Override
    protected void init() {
        panelW = 344;
        panelH = 250;
        panelX = (this.width - panelW) / 2;
        panelY = (this.height - panelH) / 2;

        EssentialConfig cfg = EssentialChatClient.config;
        int pad = 14, colGap = 8;
        int colW = (panelW - pad * 2 - colGap) / 2;
        int rowH = 18, gap = 22, firstY = panelY + 32;
        int col0 = panelX + pad;
        int col1 = panelX + pad + colW + colGap;

        // grid: col %2, row /2
        addRow(col0, firstY + gap * 0, colW, rowH, "Chat Highlight", I_HIGHLIGHT, () -> cfg.chatHighlight, () -> { cfg.chatHighlight = !cfg.chatHighlight; cfg.save(); });
        addRow(col1, firstY + gap * 0, colW, rowH, "Real Clock",  I_REALCLOCK, () -> cfg.showClock,     () -> { cfg.showClock = !cfg.showClock; cfg.save(); });
        addRow(col0, firstY + gap * 1, colW, rowH, "MC Clock",    I_MCCLOCK,   () -> cfg.showGameTime,  () -> { cfg.showGameTime = !cfg.showGameTime; cfg.save(); });
        addRow(col1, firstY + gap * 1, colW, rowH, "FPS",         I_FPS,       () -> cfg.showFps,       () -> { cfg.showFps = !cfg.showFps; cfg.save(); });
        addRow(col0, firstY + gap * 2, colW, rowH, "Coords",      I_GLOBE,     () -> cfg.showCoords,    () -> { cfg.showCoords = !cfg.showCoords; cfg.save(); });
        addRow(col1, firstY + gap * 2, colW, rowH, "Biome",       I_BIOME,     () -> cfg.showBiome,     () -> { cfg.showBiome = !cfg.showBiome; cfg.save(); });
        addRow(col0, firstY + gap * 3, colW, rowH, "Ping",        I_PING,      () -> cfg.showPing,      () -> { cfg.showPing = !cfg.showPing; cfg.save(); });
        addRow(col1, firstY + gap * 3, colW, rowH, "Chat Animation", I_ANIM,      () -> cfg.chatAnimation, () -> { cfg.chatAnimation = !cfg.chatAnimation; cfg.save(); });
        addRow(col0, firstY + gap * 4, colW, rowH, "Stack Msgs",  I_WARN,      () -> cfg.stackMessages, () -> { cfg.stackMessages = !cfg.stackMessages; cfg.save(); });
        addRow(col1, firstY + gap * 4, colW, rowH, "Direction",   I_DIR,       () -> cfg.showDirection, () -> { cfg.showDirection = !cfg.showDirection; cfg.save(); });
        addRow(col0, firstY + gap * 5, colW, rowH, "Day Counter", I_DAY,       () -> cfg.showDay,       () -> { cfg.showDay = !cfg.showDay; cfg.save(); });
        addRow(col1, firstY + gap * 5, colW, rowH, "CPS",         I_CPS,       () -> cfg.showCps,       () -> { cfg.showCps = !cfg.showCps; cfg.save(); });
        addRow(col0, firstY + gap * 6, colW, rowH, "Armor",       I_ARMOR,     () -> cfg.showArmor,     () -> { cfg.showArmor = !cfg.showArmor; cfg.save(); });
        addRow(col1, firstY + gap * 6, colW, rowH, "Armor HUD",   I_ARMOR,     () -> cfg.armorHud,      () -> { cfg.armorHud = !cfg.armorHud; cfg.save(); });
        addRow(col0, firstY + gap * 7, colW, rowH, "Speed",       I_SPEED,     () -> cfg.showSpeed,     () -> { cfg.showSpeed = !cfg.showSpeed; cfg.save(); });
        addRow(col1, firstY + gap * 7, colW, rowH, "Item Dura",   I_HELD,      () -> cfg.showHeldDura,  () -> { cfg.showHeldDura = !cfg.showHeldDura; cfg.save(); });

        int dw = 130, dh = 20;
        this.addDrawableChild(new CleanButton(panelX + (panelW - dw) / 2, firstY + gap * 8 + 2, dw, dh, "Done", this::close).check());
    }

    private void addRow(int x, int y, int w, int h, String name, Identifier icon,
                        java.util.function.BooleanSupplier g, Runnable r) {
        this.addDrawableChild(new ToggleWidget(x, y, w, h, name, icon, g, r));
    }

    // NO full-screen darkening — the game stays visible behind the menu
    @Override
    public void renderBackground(DrawContext ctx, int mouseX, int mouseY, float delta) {
        // intentionally empty
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        this.renderBackground(ctx, mouseX, mouseY, delta);

        int x1 = panelX, y1 = panelY, x2 = panelX + panelW, y2 = panelY + panelH;
        var tr = this.textRenderer;

        // soft drop shadow for depth
        ctx.fill(x1 + 4, y1 + 4, x2 + 4, y2 + 4, 0x50000000);

        // --- polished inventory panel (light grey, double-beveled) ---
        ctx.fill(x1 - 2, y1 - 2, x2 + 2, y2 + 2, 0xFF000000);   // outer black frame
        ctx.fill(x1, y1, x2, y2, 0xFFC8C8C8);                   // light grey face
        // outer bevel
        ctx.fill(x1, y1, x2, y1 + 2, 0xFFFFFFFF);               // top highlight
        ctx.fill(x1, y1, x1 + 2, y2, 0xFFFFFFFF);               // left highlight
        ctx.fill(x1, y2 - 2, x2, y2, 0xFF565656);               // bottom shadow
        ctx.fill(x2 - 2, y1, x2, y2, 0xFF565656);               // right shadow

        // --- header bar ---
        int hb = y1 + 26;                                       // header bottom
        ctx.fill(x1 + 3, y1 + 3, x2 - 3, hb, 0xFF373737);       // dark header strip
        ctx.fill(x1 + 3, y1 + 3, x2 - 3, y1 + 4, 0xFF222222);   // header top line
        ctx.fill(x1 + 3, hb, x2 - 3, hb + 1, 0xFF9AA0AA);       // divider under header

        // title: ESSENTIAL CHAT (bold, CHAT in blue) with shadow
        String left = "ESSENTIAL ", right = "CHAT";
        int tw = tr.getWidth(left + right);
        int tx = x1 + (panelW - tw) / 2, ty = y1 + 9;
        ctx.drawText(tr, net.minecraft.text.Text.literal(left).formatted(net.minecraft.util.Formatting.WHITE, net.minecraft.util.Formatting.BOLD), tx, ty, 0xFFFFFFFF, true);
        ctx.drawText(tr, net.minecraft.text.Text.literal(right).formatted(net.minecraft.util.Formatting.AQUA, net.minecraft.util.Formatting.BOLD), tx + tr.getWidth(left), ty, 0xFF4AA8F5, true);

        super.render(ctx, mouseX, mouseY, delta);
    }

    @Override
    public boolean shouldPause() { return false; }
}
