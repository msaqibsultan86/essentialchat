package studio.spark.essentialchat.client;

import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.item.ItemStack;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.Identifier;

/**
 * Shows the 4 armor pieces just left of the hotbar with a durability number.
 * When any piece drops below 10% it flashes a warning icon and plays a sound.
 */
public class ArmorHud {

    private static final Identifier WARN =
            Identifier.of("essentialchat", "textures/gui/icons/warning.png");

    private static long lastWarnSound = 0;

    public static void register() {
        HudRenderCallback.EVENT.register((ctx, tickDelta) -> {
            try { render(ctx); } catch (Throwable ignored) {}
        });
    }

    private static void render(DrawContext ctx) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.options.hudHidden) return;
        if (EssentialChatClient.config == null || !EssentialChatClient.config.armorHud) return;
        if (mc.player.isSpectator()) return;

        int sw = mc.getWindow().getScaledWidth();
        int sh = mc.getWindow().getScaledHeight();

        // hotbar is centered (182 wide). Place armor to its LEFT.
        int hotbarLeft = sw / 2 - 91;
        int x = hotbarLeft - 25;      // column just left of the hotbar
        int baseY = sh - 22;          // bottom row aligns with hotbar height

        var tr = mc.textRenderer;
        boolean anyLow = false;

        // armor list order: boots(0), leggings(1), chestplate(2), helmet(3)
        // draw helmet at top -> boots at bottom
        for (int slot = 3; slot >= 0; slot--) {
            ItemStack stack;
            try { stack = mc.player.getInventory().armor.get(slot); }
            catch (Exception e) { continue; }

            int row = 3 - slot;                 // 0..3 top to bottom
            int y = baseY - row * 20;

            if (stack == null || stack.isEmpty()) {
                // empty slot placeholder
                ctx.fill(x, y, x + 16, y + 16, 0x30000000);
                continue;
            }

            // item icon
            ctx.drawItem(stack, x, y);

            // durability %
            if (stack.isDamageable()) {
                int pct = (stack.getMaxDamage() - stack.getDamage()) * 100 / stack.getMaxDamage();
                String col = pct >= 60 ? "§a" : pct >= 25 ? "§e" : pct >= 10 ? "§6" : "§c";
                ctx.drawText(tr, col + pct + "%", x - 26, y + 4, 0xFFFFFFFF, true);

                if (pct < 10) {
                    anyLow = true;
                    // flashing warning icon next to the low piece
                    if ((System.currentTimeMillis() / 400) % 2 == 0) {
                        ctx.drawTexture(WARN, x + 17, y, 16, 16, 0, 0, 32, 32, 32, 32);
                    }
                }
            }
        }

        // low-armor warning sound (throttled to once every 3s)
        if (anyLow) {
            long now = System.currentTimeMillis();
            if (now - lastWarnSound > 3000) {
                mc.player.playSound(SoundEvents.BLOCK_NOTE_BLOCK_PLING.value(), 0.6f, 0.5f);
                lastWarnSound = now;
            }
        }
    }
}
