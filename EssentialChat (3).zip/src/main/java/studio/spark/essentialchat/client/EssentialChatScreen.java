package studio.spark.essentialchat.client;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

public class EssentialChatScreen extends Screen {

    private static final String B = "essentialchat";
    private static final Identifier BANNER = Identifier.of(B, "textures/gui/banner.png");
    private static final Identifier I_REALCLOCK = Identifier.of(B, "textures/gui/icons/realclock.png");
    private static final Identifier I_MCCLOCK   = Identifier.of(B, "textures/gui/icons/mcclock.png");
    private static final Identifier I_FPS       = Identifier.of(B, "textures/gui/icons/fps.png");
    private static final Identifier I_GLOBE     = Identifier.of(B, "textures/gui/icons/globe.png");
    private static final Identifier I_BIOME     = Identifier.of(B, "textures/gui/icons/biome.png");
    private static final Identifier I_PING      = Identifier.of(B, "textures/gui/icons/ping.png");
    private static final Identifier I_HIGHLIGHT = Identifier.of(B, "textures/gui/icons/highlight.png");
    private static final Identifier I_ANIM      = Identifier.of(B, "textures/gui/icons/animation.png");
    private static final int BANNER_W = 250, BANNER_H = 52;
    private static final int BANNER_FRAMES = 40;
    private static final int BANNER_FRAME_MS = 135;

    private int panelX, panelY, panelW, panelH;
    private final long start = System.currentTimeMillis();

    public EssentialChatScreen() { super(Text.literal("Essential Chat")); }

    @Override
    protected void init() {
        panelW = 250;
        panelH = 264;
        panelX = (this.width - panelW) / 2;
        panelY = (this.height - panelH) / 2;

        EssentialConfig cfg = EssentialChatClient.config;
        int pad = 18, rowW = panelW - pad * 2, rowX = panelX + pad;
        int rowH = 18, gap = 20, firstY = panelY + 60;

        addRow(rowX, firstY + gap * 0, rowW, rowH, "Chat Highlight", I_HIGHLIGHT,        () -> cfg.chatHighlight, () -> { cfg.chatHighlight = !cfg.chatHighlight; cfg.save(); });
        addRow(rowX, firstY + gap * 1, rowW, rowH, "Real Clock",     I_REALCLOCK, () -> cfg.showClock,     () -> { cfg.showClock = !cfg.showClock; cfg.save(); });
        addRow(rowX, firstY + gap * 2, rowW, rowH, "MC Clock",       I_MCCLOCK,   () -> cfg.showGameTime,  () -> { cfg.showGameTime = !cfg.showGameTime; cfg.save(); });
        addRow(rowX, firstY + gap * 3, rowW, rowH, "FPS",            I_FPS,       () -> cfg.showFps,       () -> { cfg.showFps = !cfg.showFps; cfg.save(); });
        addRow(rowX, firstY + gap * 4, rowW, rowH, "Coordinates",    I_GLOBE,     () -> cfg.showCoords,    () -> { cfg.showCoords = !cfg.showCoords; cfg.save(); });
        addRow(rowX, firstY + gap * 5, rowW, rowH, "Biome",          I_BIOME,     () -> cfg.showBiome,     () -> { cfg.showBiome = !cfg.showBiome; cfg.save(); });
        addRow(rowX, firstY + gap * 6, rowW, rowH, "Ping",           I_PING,      () -> cfg.showPing,      () -> { cfg.showPing = !cfg.showPing; cfg.save(); });
        addRow(rowX, firstY + gap * 7, rowW, rowH, "Chat Animation", I_ANIM,        () -> cfg.chatAnimation, () -> { cfg.chatAnimation = !cfg.chatAnimation; cfg.save(); });

        int dw = 130, dh = 20;
        this.addDrawableChild(new CleanButton(panelX + (panelW - dw) / 2, firstY + gap * 8 + 4, dw, dh, "Done", this::close).star());
    }

    private void addRow(int x, int y, int w, int h, String name, Identifier icon,
                        java.util.function.BooleanSupplier g, Runnable r) {
        this.addDrawableChild(new ToggleWidget(x, y, w, h, name, icon, g, r));
    }

    @Override
    public void renderBackground(DrawContext ctx, int mouseX, int mouseY, float delta) {
        // fully opaque solid dark = no vanilla menu blur bleeds through
        ctx.fill(0, 0, this.width, this.height, 0xFF0A0A10);
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        this.renderBackground(ctx, mouseX, mouseY, delta);
        float t = (System.currentTimeMillis() - start) / 1000f;
        float shimmer = 0.5f + 0.5f * (float) Math.sin(t * 2.4f);

        int x1 = panelX, y1 = panelY, x2 = panelX + panelW, y2 = panelY + panelH;

        // drop shadow
        ctx.fill(x1 + 5, y1 + 5, x2 + 5, y2 + 5, 0x80000000);

        // inventory-style beveled frame
        ctx.fill(x1 - 3, y1 - 3, x2 + 3, y2 + 3, 0xFF05080F);       // outer dark edge
        ctx.fill(x1 - 3, y1 - 3, x2 + 3, y1 - 1, 0xFF39628F);       // light bevel top
        ctx.fill(x1 - 3, y1 - 3, x1 - 1, y2 + 3, 0xFF39628F);       // light bevel left
        ctx.fill(x1 - 3, y2 + 1, x2 + 3, y2 + 3, 0xFF060A14);       // dark bevel bottom
        ctx.fill(x2 + 1, y1 - 3, x2 + 3, y2 + 3, 0xFF060A14);       // dark bevel right

        // main body — deep blue matching the banner
        ctx.fill(x1, y1, x2, y2, 0xFF0C1524);
        ctx.fill(x1, y1, x2, y1 + 1, 0x404A80C0);                  // top inner highlight
        ctx.fill(x1, y2 - 1, x2, y2, 0x40000000);                  // bottom inner shadow

        // inset "slot" area behind the toggle rows
        int ix1 = x1 + 8, iy1 = y1 + 58, ix2 = x2 - 8, iy2 = y1 + 206;
        ctx.fill(ix1, iy1, ix2, iy2, 0xFF08101C);
        ctx.fill(ix1, iy1, ix2, iy1 + 1, 0xFF050A12);
        ctx.fill(ix1, iy1, ix1 + 1, iy2, 0xFF050A12);
        ctx.fill(ix1, iy2 - 1, ix2, iy2, 0xFF1A3556);
        ctx.fill(ix2 - 1, iy1, ix2, iy2, 0xFF1A3556);

        // animated blue accent border
        int border = lerp(0xFF2364A8, 0xFF6FCBFF, shimmer);
        drawBorder(ctx, x1, y1, panelW, panelH, border);

        // animated banner
        int frame = (int) ((System.currentTimeMillis() / BANNER_FRAME_MS) % BANNER_FRAMES);
        int sheetH = BANNER_H * BANNER_FRAMES;
        ctx.drawTexture(BANNER, panelX, panelY, BANNER_W, BANNER_H,
                0, frame * BANNER_H, BANNER_W, BANNER_H, BANNER_W, sheetH);

        super.render(ctx, mouseX, mouseY, delta);
    }

    private void drawBorder(DrawContext ctx, int x, int y, int w, int h, int color) {
        ctx.fill(x, y, x + w, y + 1, color);
        ctx.fill(x, y + h - 1, x + w, y + h, color);
        ctx.fill(x, y, x + 1, y + h, color);
        ctx.fill(x + w - 1, y, x + w, y + h, color);
    }

    @Override
    public boolean shouldPause() { return false; }

    private static int lerp(int a, int b, float tt) {
        tt = Math.max(0f, Math.min(1f, tt));
        int aa=(a>>>24)&0xFF, ar=(a>>16)&0xFF, ag=(a>>8)&0xFF, ab=a&0xFF;
        int ba=(b>>>24)&0xFF, br=(b>>16)&0xFF, bg=(b>>8)&0xFF, bb=b&0xFF;
        return ((int)(aa+(ba-aa)*tt)<<24)|((int)(ar+(br-ar)*tt)<<16)|((int)(ag+(bg-ag)*tt)<<8)|(int)(ab+(bb-ab)*tt);
    }
}
