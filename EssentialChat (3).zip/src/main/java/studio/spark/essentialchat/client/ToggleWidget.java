package studio.spark.essentialchat.client;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.narration.NarrationMessageBuilder;
import net.minecraft.client.gui.widget.PressableWidget;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

import java.util.function.BooleanSupplier;

/** Toggle row: icon + label + a square blue ON/OFF switch. */
public class ToggleWidget extends PressableWidget {

    private final BooleanSupplier getter;
    private final Runnable onToggle;
    private final String name;
    private final Identifier icon;
    private float knob = -1f;
    private float hover = 0f;

    private static final int TRACK_W = 28, TRACK_H = 14, KNOB = 10;

    public ToggleWidget(int x, int y, int w, int h, String name, Identifier icon,
                        BooleanSupplier getter, Runnable onToggle) {
        super(x, y, w, h, Text.literal(name));
        this.name = name; this.icon = icon; this.getter = getter; this.onToggle = onToggle;
    }

    @Override
    public void onPress() {
        onToggle.run();
        MinecraftClient.getInstance().getSoundManager()
                .play(PositionedSoundInstance.master(SoundEvents.UI_BUTTON_CLICK, 1.0f));
    }

    @Override
    protected void renderWidget(DrawContext ctx, int mouseX, int mouseY, float delta) {
        boolean on = getter.getAsBoolean();
        if (knob < 0f) knob = on ? 1f : 0f;
        knob += ((on ? 1f : 0f) - knob) * 0.3f;
        hover += ((this.isHovered() ? 1f : 0f) - hover) * 0.25f;

        int x1 = getX(), y1 = getY(), x2 = getX() + getWidth(), y2 = getY() + getHeight();
        var tr = MinecraftClient.getInstance().textRenderer;

        // row background (square, subtle blue lift on hover)
        int rowBg = lerp(0xFF10141C, 0xFF182236, hover);
        ctx.fill(x1, y1, x2, y2, rowBg);
        // left accent bar (blue when on)
        ctx.fill(x1, y1, x1 + 2, y2, lerp(0xFF2A3040, 0xFF3BA9FF, knob));

        // icon + label
        int textX = x1 + 8;
        if (icon != null) {
            int sz = 10;
            ctx.drawTexture(icon, x1 + 7, y1 + (getHeight() - sz) / 2, sz, sz, 0, 0, 32, 32, 32, 32);
            textX = x1 + 7 + sz + 5;
        }
        ctx.drawTextWithShadow(tr, Text.literal(name), textX, y1 + (getHeight() - 8) / 2, 0xFFFFFFFF);

        // SQUARE switch track: grey (off) -> blue (on)
        int trackX = x2 - TRACK_W - 8;
        int trackY = y1 + (getHeight() - TRACK_H) / 2;
        int track = lerp(0xFF2A3040, 0xFF2E86F0, knob);
        ctx.fill(trackX, trackY, trackX + TRACK_W, trackY + TRACK_H, track);
        // subtle border
        int border = lerp(0xFF3A4252, 0xFF6FC0FF, knob);
        drawSquareBorder(ctx, trackX, trackY, TRACK_W, TRACK_H, border);

        // SQUARE knob, slides left/right, with drop shadow
        int knobX = trackX + 2 + (int) (knob * (TRACK_W - KNOB - 4));
        int knobY = trackY + 2;
        ctx.fill(knobX + 1, knobY + 1, knobX + KNOB + 1, knobY + KNOB + 1, 0x60000000); // shadow
        ctx.fill(knobX, knobY, knobX + KNOB, knobY + KNOB, 0xFFF7FAFF);                 // knob
    }

    private static void drawSquareBorder(DrawContext ctx, int x, int y, int w, int h, int c) {
        ctx.fill(x, y, x + w, y + 1, c);
        ctx.fill(x, y + h - 1, x + w, y + h, c);
        ctx.fill(x, y, x + 1, y + h, c);
        ctx.fill(x + w - 1, y, x + w, y + h, c);
    }

    @Override
    protected void appendClickableNarrations(NarrationMessageBuilder b) { appendDefaultNarrations(b); }

    private static int lerp(int a, int b, float t) {
        t = Math.max(0f, Math.min(1f, t));
        int aa=(a>>>24)&0xFF, ar=(a>>16)&0xFF, ag=(a>>8)&0xFF, ab=a&0xFF;
        int ba=(b>>>24)&0xFF, br=(b>>16)&0xFF, bg=(b>>8)&0xFF, bb=b&0xFF;
        return ((int)(aa+(ba-aa)*t)<<24)|((int)(ar+(br-ar)*t)<<16)|((int)(ag+(bg-ag)*t)<<8)|(int)(ab+(bb-ab)*t);
    }
}
