package studio.spark.essentialchat.client;

import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.client.screen.v1.Screens;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.client.gui.screen.GameMenuScreen;
import net.minecraft.util.Identifier;

/** Adds Essential Chat buttons to the pause menu and chat screen. */
public class ScreenInjector {

    public static void register() {
        ScreenEvents.AFTER_INIT.register((client, screen, scaledWidth, scaledHeight) -> {
            if (screen instanceof GameMenuScreen) {
                int bw = 200, bh = 20;
                Screens.getButtons(screen).add(new CleanButton(
                        (scaledWidth - bw) / 2, scaledHeight - 30, bw, bh, "Essential Chat",
                        () -> client.setScreen(new EssentialChatScreen())).star());
            } else if (screen instanceof ChatScreen) {
                // clear chat button, top-right (the spot you circled)
                Screens.getButtons(screen).add(new CleanButton(
                        scaledWidth - 88, 6, 80, 16, "Clear",
                        () -> {
                            MinecraftClient mc = MinecraftClient.getInstance();
                            if (mc.inGameHud != null) mc.inGameHud.getChatHud().clear(false);
                        }).icon(Identifier.of("essentialchat", "textures/gui/icons/clearchat.png")));
            }
        });
    }
}
