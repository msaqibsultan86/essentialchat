package studio.spark.essentialchat.client;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.narration.NarrationMessageBuilder;
import net.minecraft.client.gui.widget.PressableWidget;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

/** Button using YOUR nine-slice textures. Optional left blue star or left icon, centered. */
public class CleanButton extends PressableWidget {

    private static final Identifier TEX =
            Identifier.of("essentialchat", "widget/button");
    private static final Identifier TEX_HL =
            Identifier.of("essentialchat", "widget/button_highlighted");

    private final Runnable action;
    private boolean leftStar = false;
    private Identifier icon = null;

    private static final int STAR_R = 5;      // star radius (bigger)
    private static final int ICON_SZ = 12;

    public CleanButton(int x, int y, int w, int h, String label, Runnable action) {
        super(x, y, w, h, Text.literal(label));
        this.action = action;
    }

    public CleanButton star() { this.leftStar = true; return this; }
    public CleanButton icon(Identifier id) { this.icon = id; return this; }

    @Override
    public void onPress() {
        action.run();
        MinecraftClient.getInstance().getSoundManager()
                .play(PositionedSoundInstance.master(SoundEvents.UI_BUTTON_CLICK, 1.0f));
    }

    @Override
    protected void renderWidget(DrawContext ctx, int mouseX, int mouseY, float delta) {
        // hover swaps to YOUR highlighted texture (no glow)
        Identifier tex = this.isHovered() ? TEX_HL : TEX;
        ctx.drawGuiTexture(tex, getX(), getY(), getWidth(), getHeight());

        var tr = MinecraftClient.getInstance().textRenderer;
        Text t = getMessage();
        int textColor = this.isHovered() ? 0xFFFFFFFF : 0xFFE6ECF5;
        int textW = tr.getWidth(t);

        // measure leading element (star or icon)
        int leadW = 0;
        if (leftStar) leadW = STAR_R * 2 + 7;
        else if (icon != null) leadW = ICON_SZ + 5;

        int contentW = leadW + textW;
        int startX = getX() + (getWidth() - contentW) / 2;
        int midY = getY() + getHeight() / 2;

        if (leftStar) {
            drawStar(ctx, startX + STAR_R, midY);
            startX += STAR_R * 2 + 7;
        } else if (icon != null) {
            ctx.drawTexture(icon, startX, midY - ICON_SZ / 2, ICON_SZ, ICON_SZ, 0, 0, 32, 32, 32, 32);
            startX += ICON_SZ + 5;
        }

        ctx.drawTextWithShadow(tr, t, startX, midY - 4, textColor);
    }

    /** A rounded 4-point sparkle (diamond burst) like the Mods-menu badge, twinkling. */
    private void drawStar(DrawContext ctx, int cx, int cy) {
        float time = (System.currentTimeMillis() % 100000L) / 1000f;
        float pulse = 0.5f + 0.5f * (float) Math.sin(time * 4f);
        int glow = lerp(0xFF2E86F0, 0xFFBFE8FF, pulse);
        int edge = lerp(0xFF1C5FB0, 0xFF6FC0FF, pulse);

        // rounded diamond body (rows narrow toward the tips -> star, not plus)
        // widths per row from top tip to bottom tip
        int[] w = {0, 1, 2, 4, 6, 4, 2, 1, 0};   // 9 rows tall, fat middle = round look
        int rows = w.length;
        int top = cy - rows / 2;
        for (int i = 0; i < rows; i++) {
            int half = w[i];
            if (half <= 0) {
                // draw the sharp tip pixel
                ctx.fill(cx, top + i, cx + 1, top + i + 1, edge);
            } else {
                int y = top + i;
                boolean coreRow = Math.abs(i - rows / 2) <= 1;
                ctx.fill(cx - half, y, cx + half + 1, y + 1, coreRow ? glow : edge);
            }
        }
        // bright center core
        ctx.fill(cx - 1, cy - 1, cx + 2, cy + 2, 0xFFFFFFFF);
    }

    @Override
    protected void appendClickableNarrations(NarrationMessageBuilder b) { appendDefaultNarrations(b); }

    private static int lerp(int a, int b, float t) {
        t = Math.max(0f, Math.min(1f, t));
        int ar=(a>>16)&0xFF, ag=(a>>8)&0xFF, ab=a&0xFF;
        int br=(b>>16)&0xFF, bg=(b>>8)&0xFF, bb=b&0xFF;
        return 0xFF000000 | ((int)(ar+(br-ar)*t)<<16) | ((int)(ag+(bg-ag)*t)<<8) | (int)(ab+(bb-ab)*t);
    }
}
