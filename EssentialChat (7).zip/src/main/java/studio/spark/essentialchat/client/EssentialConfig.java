package studio.spark.essentialchat.client;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.nio.file.Files;
import java.nio.file.Path;

public class EssentialConfig {
    public boolean chatHighlight = true;
    public boolean showClock     = true;   // real-world clock
    public boolean showGameTime  = true;   // MC in-game time
    public boolean showFps       = true;
    public boolean showCoords    = true;
    public boolean showBiome     = true;   // biome name
    public boolean showPing      = true;
    public boolean hudEnabled    = true;
    public boolean chatAnimation = true;   // smooth chat slide + fade
    public boolean stackMessages = true;   // merge repeated messages into one with a counter
    public boolean showDirection = true;   // N/S/E/W facing
    public boolean showDay       = true;   // days survived
    public boolean showCps       = false;  // clicks per second
    public boolean showArmor     = false;  // armor durability %
    public boolean showLight     = false;  // light level
    public boolean showSpeed     = false;  // blocks per second
    public boolean showHeldDura  = false;  // held item durability
    public int     fadeTimeMs    = 250;    // animation duration

    private static final Path PATH =
            FabricLoader.getInstance().getConfigDir().resolve("essentialchat.json");
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    public static EssentialConfig load() {
        try {
            if (Files.exists(PATH)) {
                EssentialConfig c = GSON.fromJson(Files.readString(PATH), EssentialConfig.class);
                if (c != null) return c;
            }
        } catch (Exception ignored) {}
        EssentialConfig c = new EssentialConfig();
        c.save();
        return c;
    }

    public void save() {
        try { Files.writeString(PATH, GSON.toJson(this)); } catch (Exception ignored) {}
    }
}
