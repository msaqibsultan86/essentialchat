package studio.spark.essentialchat.client;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.narration.NarrationMessageBuilder;
import net.minecraft.client.gui.widget.PressableWidget;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

/** Light grey Minecraft inventory-style button (matches the light panel). Optional icon. */
public class CleanButton extends PressableWidget {

    private final Runnable action;
    private Identifier icon = null;
    private boolean showCheck = false;
    private float hover = 0f;

    public CleanButton(int x, int y, int w, int h, String label, Runnable action) {
        super(x, y, w, h, Text.literal(label));
        this.action = action;
    }

    public CleanButton icon(Identifier id) { this.icon = id; return this; }
    public CleanButton check() { this.showCheck = true; return this; }

    @Override
    public void onPress() {
        action.run();
        MinecraftClient.getInstance().getSoundManager()
                .play(PositionedSoundInstance.master(SoundEvents.UI_BUTTON_CLICK, 1.0f));
    }

    @Override
    protected void renderWidget(DrawContext ctx, int mouseX, int mouseY, float delta) {
        hover += ((this.isHovered() ? 1f : 0f) - hover) * 0.25f;
        int x1 = getX(), y1 = getY(), x2 = getX() + getWidth(), y2 = getY() + getHeight();

        // grey button face (lightens slightly on hover)
        int face = lerp(0xFFA0A0A0, 0xFFB8C4E0, hover);   // hover gets a faint blue tint
        ctx.fill(x1, y1, x2, y2, 0xFF000000);             // outline
        ctx.fill(x1 + 1, y1 + 1, x2 - 1, y2 - 1, face);
        ctx.fill(x1 + 1, y1 + 1, x2 - 1, y1 + 2, 0xFFFFFFFF);   // top highlight
        ctx.fill(x1 + 1, y1 + 1, x1 + 2, y2 - 1, 0xFFFFFFFF);   // left highlight
        ctx.fill(x1 + 1, y2 - 2, x2 - 1, y2 - 1, 0xFF555555);   // bottom shadow
        ctx.fill(x2 - 2, y1 + 1, x2 - 1, y2 - 1, 0xFF555555);   // right shadow

        var tr = MinecraftClient.getInstance().textRenderer;
        Text t = getMessage();
        int textW = tr.getWidth(t);
        int iconSz = 12;
        int checkW = showCheck ? 11 : 0;   // green tick width + gap
        int contentW = (icon != null ? iconSz + 4 : 0) + checkW + textW;
        int startX = x1 + (getWidth() - contentW) / 2;
        int midY = y1 + getHeight() / 2;

        if (icon != null) {
            ctx.drawTexture(icon, startX, midY - iconSz / 2, iconSz, iconSz, 0, 0, 32, 32, 32, 32);
            startX += iconSz + 4;
        }
        if (showCheck) {
            drawCheck(ctx, startX, midY - 3);
            startX += checkW;
        }
        // dark text (readable on grey)
        ctx.drawText(tr, t, startX, midY - 4, 0xFF202020, false);
    }

    /** Draws a small crisp green checkmark with a subtle dark outline. */
    private void drawCheck(DrawContext ctx, int x, int y) {
        int green = 0xFF35C24A, dark = 0xFF14591F;
        // short arm (down-right)
        for (int i = 0; i < 3; i++) {
            ctx.fill(x + i, y + 2 + i, x + i + 3, y + 2 + i + 3, dark);      // outline
            ctx.fill(x + i + 1, y + 2 + i, x + i + 2, y + 2 + i + 2, green); // fill
        }
        // long arm (up-right)
        for (int i = 0; i < 5; i++) {
            ctx.fill(x + 2 + i, y + 6 - i, x + 2 + i + 3, y + 6 - i + 3, dark);
            ctx.fill(x + 3 + i, y + 6 - i, x + 3 + i + 1, y + 6 - i + 2, green);
        }
    }

    @Override
    protected void appendClickableNarrations(NarrationMessageBuilder b) { appendDefaultNarrations(b); }

    private static int lerp(int a, int b, float t) {
        t = Math.max(0f, Math.min(1f, t));
        int ar=(a>>16)&0xFF, ag=(a>>8)&0xFF, ab=a&0xFF;
        int br=(b>>16)&0xFF, bg=(b>>8)&0xFF, bb=b&0xFF;
        return 0xFF000000 | ((int)(ar+(br-ar)*t)<<16) | ((int)(ag+(bg-ag)*t)<<8) | (int)(ab+(bb-ab)*t);
    }
}
