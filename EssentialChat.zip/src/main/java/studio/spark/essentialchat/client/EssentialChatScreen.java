package studio.spark.essentialchat.client;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

public class EssentialChatScreen extends Screen {

    private static final Identifier CREEPER =
            Identifier.of("essentialchat", "textures/gui/creeper.png");
    private static final int CREEPER_W = 112, CREEPER_H = 140;

    private int panelX, panelY, panelW, panelH;
    private final long start = System.currentTimeMillis();

    public EssentialChatScreen() {
        super(Text.literal("Essential Chat"));
    }

    @Override
    protected void init() {
        panelW = 240;
        panelH = 248;
        panelX = (this.width - panelW) / 2;
        panelY = (this.height - panelH) / 2;

        EssentialConfig cfg = EssentialChatClient.config;

        int pad = 16;
        int rowW = panelW - pad * 2;
        int rowX = panelX + pad;
        int rowH = 20, gap = 24;
        int firstY = panelY + 92;

        addRow(rowX, firstY + gap * 0, rowW, rowH, "Chat Highlight", () -> cfg.chatHighlight, () -> { cfg.chatHighlight = !cfg.chatHighlight; cfg.save(); });
        addRow(rowX, firstY + gap * 1, rowW, rowH, "Clock",          () -> cfg.showClock,     () -> { cfg.showClock = !cfg.showClock; cfg.save(); });
        addRow(rowX, firstY + gap * 2, rowW, rowH, "FPS",            () -> cfg.showFps,       () -> { cfg.showFps = !cfg.showFps; cfg.save(); });
        addRow(rowX, firstY + gap * 3, rowW, rowH, "Coordinates",    () -> cfg.showCoords,    () -> { cfg.showCoords = !cfg.showCoords; cfg.save(); });
        addRow(rowX, firstY + gap * 4, rowW, rowH, "Ping",           () -> cfg.showPing,      () -> { cfg.showPing = !cfg.showPing; cfg.save(); });

        // Done button — centered, blue, like the reference
        int dw = 120, dh = 20;
        this.addDrawableChild(ButtonWidget.builder(Text.literal("Done"),
                b -> this.close())
                .dimensions(panelX + (panelW - dw) / 2, firstY + gap * 5 + 8, dw, dh).build());
    }

    private void addRow(int x, int y, int w, int h, String name, java.util.function.BooleanSupplier g, Runnable r) {
        this.addDrawableChild(new ToggleWidget(x, y, w, h, name, g, r));
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        this.renderBackground(ctx, mouseX, mouseY, delta);
        float t = (System.currentTimeMillis() - start) / 1000f;
        float shimmer = 0.5f + 0.5f * (float) Math.sin(t * 2.2f);

        // --- main dark panel ---
        ctx.fill(panelX, panelY, panelX + panelW, panelY + panelH, 0xF0121218);
        // animated blue accent border (the "sparkle")
        int border = lerp(0xFF1E6FB0, 0xFF5BC0FF, shimmer);
        drawBorder(ctx, panelX, panelY, panelW, panelH, border);
        // header divider line under the title area
        ctx.fill(panelX + 12, panelY + 86, panelX + panelW - 12, panelY + 87, 0xFF2A2A33);

        // --- creeper logo (centered, gentle bob) ---
        int bob = (int) (Math.sin(t * 2f) * 3f);
        int logoW = 56, logoH = 70;
        int cx = panelX + (panelW - logoW) / 2;
        int cy = panelY - 34 + bob;
        ctx.drawTexture(CREEPER, cx, cy, logoW, logoH, 0, 0, CREEPER_W, CREEPER_H, CREEPER_W, CREEPER_H);

        // --- title + subtitle (centered) ---
        int titleColor = lerp(0xFF3BA9FF, 0xFFB0E4FF, shimmer);
        ctx.drawCenteredTextWithShadow(this.textRenderer, Text.literal("§lESSENTIAL CHAT"),
                this.width / 2, panelY + 56, titleColor);
        ctx.drawCenteredTextWithShadow(this.textRenderer, Text.literal("§7by Spark Studios"),
                this.width / 2, panelY + 70, 0xFF888899);

        super.render(ctx, mouseX, mouseY, delta);

        // --- thank-you line (centered, pulsing heart) ---
        float hb = 0.6f + 0.4f * (float) Math.sin(t * 3f);
        int heart = lerp(0xFF2E8B57, 0xFF55FF8A, hb);
        String thanks = "Thank You For Downloading ";
        int tw = this.textRenderer.getWidth(thanks + "\u2665");
        int tx = this.width / 2 - tw / 2;
        int ty = panelY + panelH - 15;
        ctx.drawTextWithShadow(this.textRenderer, Text.literal("§f" + thanks), tx, ty, 0xFFFFFFFF);
        ctx.drawTextWithShadow(this.textRenderer, Text.literal("\u2665"),
                tx + this.textRenderer.getWidth(thanks), ty, heart);
    }

    private void drawBorder(DrawContext ctx, int x, int y, int w, int h, int color) {
        ctx.fill(x, y, x + w, y + 1, color);
        ctx.fill(x, y + h - 1, x + w, y + h, color);
        ctx.fill(x, y, x + 1, y + h, color);
        ctx.fill(x + w - 1, y, x + w, y + h, color);
    }

    @Override
    public boolean shouldPause() { return false; }

    private static int lerp(int a, int b, float tt) {
        tt = Math.max(0f, Math.min(1f, tt));
        int aa=(a>>>24)&0xFF, ar=(a>>16)&0xFF, ag=(a>>8)&0xFF, ab=a&0xFF;
        int ba=(b>>>24)&0xFF, br=(b>>16)&0xFF, bg=(b>>8)&0xFF, bb=b&0xFF;
        return ((int)(aa+(ba-aa)*tt)<<24)|((int)(ar+(br-ar)*tt)<<16)|((int)(ag+(bg-ag)*tt)<<8)|(int)(ab+(bb-ab)*tt);
    }
}
