package studio.spark.essentialchat.client;

import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.client.render.RenderTickCounter;

import java.text.SimpleDateFormat;
import java.util.Date;

public class HudOverlay {

    private static final SimpleDateFormat CLOCK = new SimpleDateFormat("HH:mm:ss");

    public static void register() {
        HudRenderCallback.EVENT.register(HudOverlay::onRender);
    }

    private static void onRender(DrawContext ctx, RenderTickCounter tick) {
        MinecraftClient mc = MinecraftClient.getInstance();
        EssentialConfig cfg = EssentialChatClient.config;
        if (cfg == null || !cfg.hudEnabled) return;
        if (mc.player == null || mc.options.hudHidden) return;

        int x = 4;
        int y = 4;
        int line = 10;

        if (cfg.showClock) {
            ctx.drawTextWithShadow(mc.textRenderer, "§e" + CLOCK.format(new Date()), x, y, 0xFFFFFFFF);
            y += line;
        }
        if (cfg.showFps) {
            ctx.drawTextWithShadow(mc.textRenderer, "§a" + mc.getCurrentFps() + " FPS", x, y, 0xFFFFFFFF);
            y += line;
        }
        if (cfg.showCoords) {
            String coords = String.format("§bX §f%.1f §bY §f%.1f §bZ §f%.1f",
                    mc.player.getX(), mc.player.getY(), mc.player.getZ());
            ctx.drawTextWithShadow(mc.textRenderer, coords, x, y, 0xFFFFFFFF);
            y += line;
        }
        if (cfg.showPing) {
            int ping = 0;
            if (mc.getNetworkHandler() != null) {
                PlayerListEntry e = mc.getNetworkHandler().getPlayerListEntry(mc.player.getUuid());
                if (e != null) ping = e.getLatency();
            }
            ctx.drawTextWithShadow(mc.textRenderer, "§d" + ping + " ms", x, y, 0xFFFFFFFF);
        }
    }
}
