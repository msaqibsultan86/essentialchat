package studio.spark.essentialchat.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.message.v1.ClientReceiveMessageEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import org.lwjgl.glfw.GLFW;

public class EssentialChatClient implements ClientModInitializer {

    public static EssentialConfig config;
    public static String lastMessage = "";   // captured for "copy last message"

    private static KeyBinding openMenu;
    private static KeyBinding toggleHud;
    private static KeyBinding clearChat;
    private static KeyBinding copyLastMsg;
    private static KeyBinding copyCoords;

    @Override
    public void onInitializeClient() {
        config = EssentialConfig.load();

        // --- keybinds (all rebindable in Controls) ---
        openMenu    = reg("open_menu",     GLFW.GLFW_KEY_O);
        toggleHud   = reg("toggle_hud",    GLFW.GLFW_KEY_H);
        clearChat   = reg("clear_chat",    GLFW.GLFW_KEY_DELETE);
        copyLastMsg = reg("copy_last_msg", GLFW.GLFW_KEY_N);
        copyCoords  = reg("copy_coords",   GLFW.GLFW_KEY_J);

        // --- capture incoming messages (for highlight + copy last) ---
        ClientReceiveMessageEvents.ALLOW_GAME.register((message, overlay) -> {
            if (!overlay) handleIncoming(message);
            return true;
        });
        ClientReceiveMessageEvents.ALLOW_CHAT.register((message, signed, sender, params, ts) -> {
            handleIncoming(message);
            return true;
        });

        // --- HUD overlay ---
        HudOverlay.register();

        // --- key handling ---
        ClientTickEvents.END_CLIENT_TICK.register(this::onTick);
    }

    private static KeyBinding reg(String name, int key) {
        return KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.essentialchat." + name, InputUtil.Type.KEYSYM, key, "category.essentialchat"));
    }

    private void handleIncoming(Text message) {
        if (message == null) return;
        String text = message.getString();
        lastMessage = text;

        MinecraftClient mc = MinecraftClient.getInstance();
        if (config.chatHighlight && mc.player != null) {
            String myName = mc.player.getGameProfile().getName();
            if (myName != null && !myName.isEmpty()
                    && text.toLowerCase().contains(myName.toLowerCase())) {
                // ping! play a clear notification sound
                mc.player.playSound(SoundEvents.ENTITY_EXPERIENCE_ORB_PICKUP, 1.0f, 1.2f);
            }
        }
    }

    private void onTick(MinecraftClient mc) {
        if (mc.player == null) return;

        while (openMenu.wasPressed()) {
            mc.setScreen(new EssentialChatScreen());
        }
        while (toggleHud.wasPressed()) {
            config.hudEnabled = !config.hudEnabled;
            config.save();
            msg(mc, "HUD " + (config.hudEnabled ? "§aon" : "§coff"));
        }
        while (clearChat.wasPressed()) {
            mc.inGameHud.getChatHud().clear(false);
        }
        while (copyLastMsg.wasPressed()) {
            if (!lastMessage.isEmpty()) {
                mc.keyboard.setClipboard(lastMessage);
                msg(mc, "§aCopied last message");
            }
        }
        while (copyCoords.wasPressed()) {
            String c = String.format("%.0f %.0f %.0f",
                    mc.player.getX(), mc.player.getY(), mc.player.getZ());
            mc.keyboard.setClipboard(c);
            msg(mc, "§aCopied coords: §f" + c);
        }
    }

    private void msg(MinecraftClient mc, String s) {
        if (mc.player != null) {
            mc.player.sendMessage(Text.literal("§d[EC] §r" + s), false);
        }
    }
}
