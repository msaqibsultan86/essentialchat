package studio.spark.essentialchat.client;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.narration.NarrationMessageBuilder;
import net.minecraft.client.gui.widget.PressableWidget;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;

import java.util.function.BooleanSupplier;

/** A clean row: label on the left, an animated ON/OFF slider switch on the right. */
public class ToggleWidget extends PressableWidget {

    private final BooleanSupplier getter;
    private final Runnable onToggle;
    private final String name;
    private float knob = -1f;   // animated 0(off)->1(on); -1 = uninitialised
    private float hover = 0f;

    // slider dimensions
    private static final int TRACK_W = 26, TRACK_H = 12, KNOB = 10;

    public ToggleWidget(int x, int y, int w, int h, String name, BooleanSupplier getter, Runnable onToggle) {
        super(x, y, w, h, Text.literal(name));
        this.name = name;
        this.getter = getter;
        this.onToggle = onToggle;
    }

    @Override
    public void onPress() {
        onToggle.run();
        MinecraftClient.getInstance().getSoundManager()
                .play(PositionedSoundInstance.master(SoundEvents.UI_BUTTON_CLICK, 1.0f));
    }

    @Override
    protected void renderWidget(DrawContext ctx, int mouseX, int mouseY, float delta) {
        boolean on = getter.getAsBoolean();
        if (knob < 0f) knob = on ? 1f : 0f;            // init without animating
        knob += ((on ? 1f : 0f) - knob) * 0.3f;        // smooth slide
        hover += ((this.isHovered() ? 1f : 0f) - hover) * 0.25f;

        int x1 = getX(), y1 = getY(), x2 = getX() + getWidth(), y2 = getY() + getHeight();
        var tr = MinecraftClient.getInstance().textRenderer;

        // row background (subtle, lifts on hover) — matches the dark panel rows
        int rowBg = lerp(0xFF1B1B22, 0xFF24242E, hover);
        pill(ctx, x1, y1, x2, y2, rowBg);

        // label, vertically centred
        ctx.drawTextWithShadow(tr, Text.literal(name), x1 + 8, y1 + (getHeight() - 8) / 2, 0xFFFFFFFF);

        // --- slider switch (right aligned) ---
        int trackX = x2 - TRACK_W - 8;
        int trackY = y1 + (getHeight() - TRACK_H) / 2;
        int trackColor = lerp(0xFF3A3A44, 0xFF3B82F6, knob);   // grey -> blue
        pill(ctx, trackX, trackY, trackX + TRACK_W, trackY + TRACK_H, trackColor);

        // knob slides left->right
        int knobX = trackX + 1 + (int) (knob * (TRACK_W - KNOB - 2));
        int knobY = trackY + 1;
        pill(ctx, knobX, knobY, knobX + KNOB, knobY + KNOB, 0xFFF5F5F5);
    }

    /** Draws a rectangle with the 4 corner pixels trimmed = clean rounded-pill look. */
    private static void pill(DrawContext ctx, int x1, int y1, int x2, int y2, int color) {
        ctx.fill(x1 + 1, y1, x2 - 1, y2, color);       // main body
        ctx.fill(x1, y1 + 1, x1 + 1, y2 - 1, color);   // left edge
        ctx.fill(x2 - 1, y1 + 1, x2, y2 - 1, color);   // right edge
    }

    @Override
    protected void appendClickableNarrations(NarrationMessageBuilder builder) {
        appendDefaultNarrations(builder);
    }

    private static int lerp(int a, int b, float t) {
        t = Math.max(0f, Math.min(1f, t));
        int aa=(a>>>24)&0xFF, ar=(a>>16)&0xFF, ag=(a>>8)&0xFF, ab=a&0xFF;
        int ba=(b>>>24)&0xFF, br=(b>>16)&0xFF, bg=(b>>8)&0xFF, bb=b&0xFF;
        return ((int)(aa+(ba-aa)*t)<<24)|((int)(ar+(br-ar)*t)<<16)|((int)(ag+(bg-ag)*t)<<8)|(int)(ab+(bb-ab)*t);
    }
}
