package studio.spark.essentialchat.client;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.nio.file.Files;
import java.nio.file.Path;

/** Saved to config/essentialchat.json — toggle each feature. */
public class EssentialConfig {
    public boolean chatHighlight = true;   // ping sound when your name is said
    public boolean showClock     = true;   // real-world time
    public boolean showFps       = true;   // FPS counter
    public boolean showCoords    = true;   // X/Y/Z
    public boolean showPing      = true;   // your ping in ms
    public boolean hudEnabled    = true;   // master toggle for the HUD

    private static final Path PATH =
            FabricLoader.getInstance().getConfigDir().resolve("essentialchat.json");
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    public static EssentialConfig load() {
        try {
            if (Files.exists(PATH)) {
                EssentialConfig c = GSON.fromJson(Files.readString(PATH), EssentialConfig.class);
                if (c != null) return c;
            }
        } catch (Exception ignored) {}
        EssentialConfig c = new EssentialConfig();
        c.save();
        return c;
    }

    public void save() {
        try {
            Files.writeString(PATH, GSON.toJson(this));
        } catch (Exception ignored) {}
    }
}
