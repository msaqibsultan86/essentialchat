package studio.spark.essentialchat.client;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

public class EssentialChatScreen extends Screen {

    private static final String B = "essentialchat";
    private static final Identifier LOGO = Identifier.of(B, "textures/gui/logo.png");
    private static final Identifier I_REALCLOCK = Identifier.of(B, "textures/gui/icons/realclock.png");
    private static final Identifier I_MCCLOCK   = Identifier.of(B, "textures/gui/icons/mcclock.png");
    private static final Identifier I_FPS       = Identifier.of(B, "textures/gui/icons/fps.png");
    private static final Identifier I_GLOBE     = Identifier.of(B, "textures/gui/icons/globe.png");
    private static final Identifier I_BIOME     = Identifier.of(B, "textures/gui/icons/biome.png");
    private static final Identifier I_PING      = Identifier.of(B, "textures/gui/icons/ping.png");
    private static final int LOGO_W = 504, LOGO_H = 60;

    private int panelX, panelY, panelW, panelH;
    private final long start = System.currentTimeMillis();

    public EssentialChatScreen() { super(Text.literal("Essential Chat")); }

    @Override
    protected void init() {
        panelW = 250;
        panelH = 264;
        panelX = (this.width - panelW) / 2;
        panelY = (this.height - panelH) / 2;

        EssentialConfig cfg = EssentialChatClient.config;
        int pad = 18, rowW = panelW - pad * 2, rowX = panelX + pad;
        int rowH = 18, gap = 20, firstY = panelY + 60;

        addRow(rowX, firstY + gap * 0, rowW, rowH, "Chat Highlight", null,        () -> cfg.chatHighlight, () -> { cfg.chatHighlight = !cfg.chatHighlight; cfg.save(); });
        addRow(rowX, firstY + gap * 1, rowW, rowH, "Real Clock",     I_REALCLOCK, () -> cfg.showClock,     () -> { cfg.showClock = !cfg.showClock; cfg.save(); });
        addRow(rowX, firstY + gap * 2, rowW, rowH, "MC Clock",       I_MCCLOCK,   () -> cfg.showGameTime,  () -> { cfg.showGameTime = !cfg.showGameTime; cfg.save(); });
        addRow(rowX, firstY + gap * 3, rowW, rowH, "FPS",            I_FPS,       () -> cfg.showFps,       () -> { cfg.showFps = !cfg.showFps; cfg.save(); });
        addRow(rowX, firstY + gap * 4, rowW, rowH, "Coordinates",    I_GLOBE,     () -> cfg.showCoords,    () -> { cfg.showCoords = !cfg.showCoords; cfg.save(); });
        addRow(rowX, firstY + gap * 5, rowW, rowH, "Biome",          I_BIOME,     () -> cfg.showBiome,     () -> { cfg.showBiome = !cfg.showBiome; cfg.save(); });
        addRow(rowX, firstY + gap * 6, rowW, rowH, "Ping",           I_PING,      () -> cfg.showPing,      () -> { cfg.showPing = !cfg.showPing; cfg.save(); });
        addRow(rowX, firstY + gap * 7, rowW, rowH, "Minimap",        null,        () -> cfg.showMinimap,   () -> { cfg.showMinimap = !cfg.showMinimap; cfg.save(); });

        int dw = 130, dh = 20;
        this.addDrawableChild(new CleanButton(panelX + (panelW - dw) / 2, firstY + gap * 8 + 4, dw, dh, "\u2726 Done", this::close));
    }

    private void addRow(int x, int y, int w, int h, String name, Identifier icon,
                        java.util.function.BooleanSupplier g, Runnable r) {
        this.addDrawableChild(new ToggleWidget(x, y, w, h, name, icon, g, r));
    }

    @Override
    public void renderBackground(DrawContext ctx, int mouseX, int mouseY, float delta) {
        ctx.fill(0, 0, this.width, this.height, 0xCC08080C);
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        this.renderBackground(ctx, mouseX, mouseY, delta);
        float t = (System.currentTimeMillis() - start) / 1000f;
        float shimmer = 0.5f + 0.5f * (float) Math.sin(t * 2.4f);

        // panel drop shadow
        ctx.fill(panelX + 4, panelY + 4, panelX + panelW + 4, panelY + panelH + 4, 0x70000000);
        // panel body (deep blue-black)
        ctx.fill(panelX, panelY, panelX + panelW, panelY + panelH, 0xFF0B1018);
        // sparkling blue border (animated)
        int border = lerp(0xFF2364A8, 0xFF6FCBFF, shimmer);
        drawBorder(ctx, panelX, panelY, panelW, panelH, border);
        // inner subtle blue glow line
        ctx.fill(panelX + 1, panelY + 1, panelX + panelW - 1, panelY + 2, 0x203BA9FF);

        // logo (gentle bob)
        int bob = (int) (Math.sin(t * 2f) * 2f);
        int bw = 190, bh = bw * LOGO_H / LOGO_W;
        int bx = panelX + (panelW - bw) / 2, by = panelY + 11 + bob;
        ctx.drawTexture(LOGO, bx, by, bw, bh, 0, 0, LOGO_W, LOGO_H, LOGO_W, LOGO_H);

        // divider
        ctx.fill(panelX + 14, panelY + 52, panelX + panelW - 14, panelY + 53, 0xFF1C3450);

        super.render(ctx, mouseX, mouseY, delta);
    }

    private void drawBorder(DrawContext ctx, int x, int y, int w, int h, int color) {
        ctx.fill(x, y, x + w, y + 1, color);
        ctx.fill(x, y + h - 1, x + w, y + h, color);
        ctx.fill(x, y, x + 1, y + h, color);
        ctx.fill(x + w - 1, y, x + w, y + h, color);
    }

    @Override
    public boolean shouldPause() { return false; }

    private static int lerp(int a, int b, float tt) {
        tt = Math.max(0f, Math.min(1f, tt));
        int aa=(a>>>24)&0xFF, ar=(a>>16)&0xFF, ag=(a>>8)&0xFF, ab=a&0xFF;
        int ba=(b>>>24)&0xFF, br=(b>>16)&0xFF, bg=(b>>8)&0xFF, bb=b&0xFF;
        return ((int)(aa+(ba-aa)*tt)<<24)|((int)(ar+(br-ar)*tt)<<16)|((int)(ag+(bg-ag)*tt)<<8)|(int)(ab+(bb-ab)*tt);
    }
}
