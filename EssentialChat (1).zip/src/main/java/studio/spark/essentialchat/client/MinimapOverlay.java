package studio.spark.essentialchat.client;

import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.block.BlockState;
import net.minecraft.block.MapColor;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.Heightmap;

/** Basic circular minimap (north-up). Samples the top block's map color around the player. */
public class MinimapOverlay {

    private static final int BLOCKS = 48;       // sampled area (BLOCKS x BLOCKS)
    private static final int CELL = 2;          // pixels per block
    private static final int DIAM = BLOCKS * CELL;
    private static final int[] cache = new int[BLOCKS * BLOCKS];
    private static long lastSample = -100;

    public static void register() {
        HudRenderCallback.EVENT.register(MinimapOverlay::onRender);
    }

    private static void onRender(DrawContext ctx, RenderTickCounter tick) {
        MinecraftClient mc = MinecraftClient.getInstance();
        EssentialConfig cfg = EssentialChatClient.config;
        if (cfg == null || !cfg.showMinimap || !cfg.hudEnabled) return;
        if (mc.player == null || mc.world == null || mc.options.hudHidden) return;

        long now = mc.world.getTime();
        if (now - lastSample >= 10) { sample(mc); lastSample = now; }

        int sw = ctx.getScaledWindowWidth();
        int mapX = sw - DIAM - 10;
        int mapY = 10;
        int cxp = mapX + DIAM / 2;
        int cyp = mapY + DIAM / 2;
        int r = DIAM / 2;

        // dark backdrop ring
        ctx.fill(mapX - 2, mapY - 2, mapX + DIAM + 2, mapY + DIAM + 2, 0x80000000);

        // draw cells inside the circle
        for (int gz = 0; gz < BLOCKS; gz++) {
            for (int gx = 0; gx < BLOCKS; gx++) {
                int px = mapX + gx * CELL;
                int py = mapY + gz * CELL;
                int ddx = px + CELL / 2 - cxp;
                int ddy = py + CELL / 2 - cyp;
                if (ddx * ddx + ddy * ddy > r * r) continue;
                ctx.fill(px, py, px + CELL, py + CELL, cache[gz * BLOCKS + gx]);
            }
        }

        // player dot (center)
        ctx.fill(cxp - 1, cyp - 1, cxp + 2, cyp + 2, 0xFFFFFFFF);

        // N / S / E / W
        var tr = mc.textRenderer;
        ctx.drawTextWithShadow(tr, Text.literal("§fN"), cxp - 3, mapY - 1, 0xFFFFFFFF);
        ctx.drawTextWithShadow(tr, Text.literal("§7S"), cxp - 3, mapY + DIAM - 8, 0xFFFFFFFF);
        ctx.drawTextWithShadow(tr, Text.literal("§7W"), mapX + 1, cyp - 4, 0xFFFFFFFF);
        ctx.drawTextWithShadow(tr, Text.literal("§7E"), mapX + DIAM - 6, cyp - 4, 0xFFFFFFFF);
    }

    private static void sample(MinecraftClient mc) {
        var world = mc.world;
        int px = (int) Math.floor(mc.player.getX());
        int pz = (int) Math.floor(mc.player.getZ());
        int half = BLOCKS / 2;
        for (int gz = 0; gz < BLOCKS; gz++) {
            for (int gx = 0; gx < BLOCKS; gx++) {
                int wx = px - half + gx;
                int wz = pz - half + gz;
                int topY = world.getTopY(Heightmap.Type.WORLD_SURFACE, wx, wz);
                BlockPos bp = new BlockPos(wx, topY - 1, wz);
                BlockState st = world.getBlockState(bp);
                MapColor col = st.getMapColor(world, bp);
                int rgb = col.getRenderColor(MapColor.Brightness.NORMAL);
                cache[gz * BLOCKS + gx] = 0xFF000000 | (rgb & 0xFFFFFF);
            }
        }
    }
}
