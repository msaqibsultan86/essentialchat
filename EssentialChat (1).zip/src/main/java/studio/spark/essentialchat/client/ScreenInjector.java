package studio.spark.essentialchat.client;

import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.client.screen.v1.Screens;
import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.client.gui.screen.GameMenuScreen;

/** Adds an Essential Chat button to the pause (ESC) menu and the chat screen. */
public class ScreenInjector {

    public static void register() {
        ScreenEvents.AFTER_INIT.register((client, screen, scaledWidth, scaledHeight) -> {
            if (screen instanceof GameMenuScreen) {
                // centered, below "Save and Quit to Title"
                int bw = 200, bh = 20;
                Screens.getButtons(screen).add(new CleanButton(
                        (scaledWidth - bw) / 2, scaledHeight - 30, bw, bh, "\u2726 Essential Chat",
                        () -> client.setScreen(new EssentialChatScreen())));
            } else if (screen instanceof ChatScreen) {
                Screens.getButtons(screen).add(new CleanButton(
                        scaledWidth - 70, 6, 62, 16, "\u2726 EC",
                        () -> client.setScreen(new EssentialChatScreen())));
            }
        });
    }
}
