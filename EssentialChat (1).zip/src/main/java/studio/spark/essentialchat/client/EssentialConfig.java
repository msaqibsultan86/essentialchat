package studio.spark.essentialchat.client;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.nio.file.Files;
import java.nio.file.Path;

public class EssentialConfig {
    public boolean chatHighlight = true;
    public boolean showClock     = true;   // real-world clock
    public boolean showGameTime  = true;   // MC in-game time
    public boolean showFps       = true;
    public boolean showCoords    = true;
    public boolean showBiome     = true;   // biome name
    public boolean showPing      = true;
    public boolean showMinimap   = true;   // circular minimap (experimental)
    public boolean hudEnabled    = true;

    private static final Path PATH =
            FabricLoader.getInstance().getConfigDir().resolve("essentialchat.json");
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    public static EssentialConfig load() {
        try {
            if (Files.exists(PATH)) {
                EssentialConfig c = GSON.fromJson(Files.readString(PATH), EssentialConfig.class);
                if (c != null) return c;
            }
        } catch (Exception ignored) {}
        EssentialConfig c = new EssentialConfig();
        c.save();
        return c;
    }

    public void save() {
        try { Files.writeString(PATH, GSON.toJson(this)); } catch (Exception ignored) {}
    }
}
