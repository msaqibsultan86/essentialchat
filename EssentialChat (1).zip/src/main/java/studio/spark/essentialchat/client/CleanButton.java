package studio.spark.essentialchat.client;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.narration.NarrationMessageBuilder;
import net.minecraft.client.gui.widget.PressableWidget;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;

/** Polished blue sparkling button: drop shadow, animated shimmer edge, smooth hover. */
public class CleanButton extends PressableWidget {

    private final Runnable action;
    private float hover = 0f;
    private final long start = System.currentTimeMillis();

    public CleanButton(int x, int y, int w, int h, String label, Runnable action) {
        super(x, y, w, h, Text.literal(label));
        this.action = action;
    }

    @Override
    public void onPress() {
        action.run();
        MinecraftClient.getInstance().getSoundManager()
                .play(PositionedSoundInstance.master(SoundEvents.UI_BUTTON_CLICK, 1.0f));
    }

    @Override
    protected void renderWidget(DrawContext ctx, int mouseX, int mouseY, float delta) {
        hover += ((this.isHovered() ? 1f : 0f) - hover) * 0.25f;
        float t = (System.currentTimeMillis() - start) / 1000f;
        float shimmer = 0.5f + 0.5f * (float) Math.sin(t * 3f);

        int x1 = getX(), y1 = getY(), x2 = getX() + getWidth(), y2 = getY() + getHeight();

        // drop shadow
        ctx.fill(x1 + 2, y1 + 2, x2 + 2, y2 + 2, 0x60000000);

        // body: dark blue -> lighter blue on hover
        int body = lerp(0xFF10233F, 0xFF1C4C86, hover);
        ctx.fill(x1, y1, x2, y2, body);

        // animated sparkling blue border
        int border = lerp(0xFF2E6FB0, 0xFF6FCBFF, shimmer);
        ctx.fill(x1, y1, x2, y1 + 1, border);
        ctx.fill(x1, y2 - 1, x2, y2, border);
        ctx.fill(x1, y1, x1 + 1, y2, border);
        ctx.fill(x2 - 1, y1, x2, y2, border);

        // top glossy highlight
        ctx.fill(x1 + 1, y1 + 1, x2 - 1, y1 + 2, lerp(0x30FFFFFF, 0x70FFFFFF, hover));

        var tr = MinecraftClient.getInstance().textRenderer;
        Text txt = getMessage();
        ctx.drawTextWithShadow(tr, txt, x1 + (getWidth() - tr.getWidth(txt)) / 2,
                y1 + (getHeight() - 8) / 2, 0xFFFFFFFF);
    }

    @Override
    protected void appendClickableNarrations(NarrationMessageBuilder b) { appendDefaultNarrations(b); }

    private static int lerp(int a, int b, float t) {
        t = Math.max(0f, Math.min(1f, t));
        int aa=(a>>>24)&0xFF, ar=(a>>16)&0xFF, ag=(a>>8)&0xFF, ab=a&0xFF;
        int ba=(b>>>24)&0xFF, br=(b>>16)&0xFF, bg=(b>>8)&0xFF, bb=b&0xFF;
        return ((int)(aa+(ba-aa)*t)<<24)|((int)(ar+(br-ar)*t)<<16)|((int)(ag+(bg-ag)*t)<<8)|(int)(ab+(bb-ab)*t);
    }
}
