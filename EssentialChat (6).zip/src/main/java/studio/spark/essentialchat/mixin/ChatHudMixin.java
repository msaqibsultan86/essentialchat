package studio.spark.essentialchat.mixin;

import com.llamalad7.mixinextras.injector.wrapmethod.WrapMethod;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.sugar.Local;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.hud.ChatHud;
import net.minecraft.client.gui.hud.ChatHudLine;
import net.minecraft.client.gui.hud.MessageIndicator;
import net.minecraft.network.message.MessageSignatureData;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import studio.spark.essentialchat.client.ChatAnim;
import studio.spark.essentialchat.client.EssentialChatClient;

/** Essential Chat: smooth message slide-up + fade-in. Original implementation. */
@Mixin(ChatHud.class)
public class ChatHudMixin {

    @Shadow private int scrolledLines;
    @Unique private long essential$newestMessageAt = 0L;

    @Shadow private int getLineHeight() { return 9; }

    @Inject(method = "addMessage(Lnet/minecraft/text/Text;Lnet/minecraft/network/message/MessageSignatureData;Lnet/minecraft/client/gui/hud/MessageIndicator;)V", at = @At("TAIL"))
    private void essential$markNewMessage(Text message, MessageSignatureData sig,
                                          MessageIndicator indicator, CallbackInfo ci) {
        this.essential$newestMessageAt = System.currentTimeMillis();
    }

    @WrapMethod(method = "render")
    private void essential$slideRender(DrawContext ctx, int currentTick, int mouseX, int mouseY,
                                       boolean focused, Operation<Void> original) {
        float offset = (this.scrolledLines == 0)
                ? ChatAnim.slideOffset(this.essential$newestMessageAt, this.getLineHeight())
                : 0f;
        ChatAnim.withSlide(ctx, offset, () -> original.call(ctx, currentTick, mouseX, mouseY, focused));
    }

    @ModifyVariable(method = "render", at = @At("STORE"), ordinal = 3)
    private double essential$fadeMessage(double original, @Local ChatHudLine.Visible line,
                                         @Local(argsOnly = true, ordinal = 0) int currentTick) {
        return original * ChatAnim.fadeIn(currentTick - line.addedTime());
    }
}
