package studio.spark.essentialchat.client;

import net.minecraft.client.gui.DrawContext;

/** Original smooth chat animation helper for Essential Chat. */
public final class ChatAnim {

    private ChatAnim() {}

    /** Offsets the chat render vertically for the slide-in effect. */
    public static void withSlide(DrawContext ctx, float offsetY, Runnable render) {
        boolean slide = offsetY != 0.0F;
        if (slide) {
            ctx.getMatrices().push();
            ctx.getMatrices().translate(0.0F, offsetY, 0.0F);
        }
        render.run();
        if (slide) ctx.getMatrices().pop();
    }

    /** Eased fade-in (0..1) from a message's age in ticks. */
    public static double fadeIn(int ageTicks) {
        EssentialConfig cfg = EssentialChatClient.config;
        if (cfg == null || !cfg.chatAnimation) return 1.0;
        float durTicks = Math.max(1f, cfg.fadeTimeMs / 50.0F);
        float p = Math.min((float) ageTicks / durTicks, 1.0F);
        // ease-out cubic for a smoother finish
        return 1.0 - Math.pow(1.0 - p, 3);
    }

    /** How far a fresh message starts below its final spot, easing up over time. */
    public static float slideOffset(long lastMessageMs, int lineHeight) {
        EssentialConfig cfg = EssentialChatClient.config;
        if (cfg == null || !cfg.chatAnimation) return 0f;
        float dur = cfg.fadeTimeMs;
        float max = lineHeight * 0.85f;
        float p = Math.min((System.currentTimeMillis() - lastMessageMs) / dur, 1.0f);
        float eased = 1f - (float) Math.pow(1f - p, 3);   // ease-out cubic
        return max * (1f - eased);
    }
}
