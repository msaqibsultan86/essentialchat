package studio.spark.essentialchat.client;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

public class EssentialChatScreen extends Screen {

    private static final String B = "essentialchat";
    private static final Identifier LOGO = Identifier.of(B, "textures/gui/logo.png");
    private static final Identifier I_REALCLOCK = Identifier.of(B, "textures/gui/icons/realclock.png");
    private static final Identifier I_MCCLOCK   = Identifier.of(B, "textures/gui/icons/mcclock.png");
    private static final Identifier I_FPS       = Identifier.of(B, "textures/gui/icons/fps.png");
    private static final Identifier I_GLOBE     = Identifier.of(B, "textures/gui/icons/globe.png");
    private static final Identifier I_BIOME     = Identifier.of(B, "textures/gui/icons/biome.png");
    private static final Identifier I_PING      = Identifier.of(B, "textures/gui/icons/ping.png");
    private static final Identifier I_HIGHLIGHT = Identifier.of(B, "textures/gui/icons/highlight.png");
    private static final Identifier I_ANIM      = Identifier.of(B, "textures/gui/icons/animation.png");
    private static final int LOGO_W = 504, LOGO_H = 60;

    private int panelX, panelY, panelW, panelH;

    public EssentialChatScreen() { super(Text.literal("Essential Chat")); }

    @Override
    protected void init() {
        panelW = 250;
        panelH = 250;
        panelX = (this.width - panelW) / 2;
        panelY = (this.height - panelH) / 2;

        EssentialConfig cfg = EssentialChatClient.config;
        int pad = 18, rowW = panelW - pad * 2, rowX = panelX + pad;
        int rowH = 18, gap = 20, firstY = panelY + 46;

        addRow(rowX, firstY + gap * 0, rowW, rowH, "Chat Highlight", I_HIGHLIGHT, () -> cfg.chatHighlight, () -> { cfg.chatHighlight = !cfg.chatHighlight; cfg.save(); });
        addRow(rowX, firstY + gap * 1, rowW, rowH, "Real Clock",     I_REALCLOCK, () -> cfg.showClock,     () -> { cfg.showClock = !cfg.showClock; cfg.save(); });
        addRow(rowX, firstY + gap * 2, rowW, rowH, "MC Clock",       I_MCCLOCK,   () -> cfg.showGameTime,  () -> { cfg.showGameTime = !cfg.showGameTime; cfg.save(); });
        addRow(rowX, firstY + gap * 3, rowW, rowH, "FPS",            I_FPS,       () -> cfg.showFps,       () -> { cfg.showFps = !cfg.showFps; cfg.save(); });
        addRow(rowX, firstY + gap * 4, rowW, rowH, "Coordinates",    I_GLOBE,     () -> cfg.showCoords,    () -> { cfg.showCoords = !cfg.showCoords; cfg.save(); });
        addRow(rowX, firstY + gap * 5, rowW, rowH, "Biome",          I_BIOME,     () -> cfg.showBiome,     () -> { cfg.showBiome = !cfg.showBiome; cfg.save(); });
        addRow(rowX, firstY + gap * 6, rowW, rowH, "Ping",           I_PING,      () -> cfg.showPing,      () -> { cfg.showPing = !cfg.showPing; cfg.save(); });
        addRow(rowX, firstY + gap * 7, rowW, rowH, "Chat Animation", I_ANIM,      () -> cfg.chatAnimation, () -> { cfg.chatAnimation = !cfg.chatAnimation; cfg.save(); });

        int dw = 130, dh = 20;
        this.addDrawableChild(new CleanButton(panelX + (panelW - dw) / 2, firstY + gap * 8 + 4, dw, dh, "Done", this::close));
    }

    private void addRow(int x, int y, int w, int h, String name, Identifier icon,
                        java.util.function.BooleanSupplier g, Runnable r) {
        this.addDrawableChild(new ToggleWidget(x, y, w, h, name, icon, g, r));
    }

    // NO full-screen darkening — the game stays visible behind the menu
    @Override
    public void renderBackground(DrawContext ctx, int mouseX, int mouseY, float delta) {
        // intentionally empty
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        this.renderBackground(ctx, mouseX, mouseY, delta);

        int x1 = panelX, y1 = panelY, x2 = panelX + panelW, y2 = panelY + panelH;

        // --- classic Minecraft inventory-style panel (light grey, beveled) ---
        ctx.fill(x1 - 1, y1 - 1, x2 + 1, y2 + 1, 0xFF000000);   // thin outer outline
        ctx.fill(x1, y1, x2, y2, 0xFFC6C6C6);                   // light grey face
        ctx.fill(x1, y1, x2, y1 + 2, 0xFFFFFFFF);               // top highlight
        ctx.fill(x1, y1, x1 + 2, y2, 0xFFFFFFFF);               // left highlight
        ctx.fill(x1, y2 - 2, x2, y2, 0xFF555555);               // bottom shadow
        ctx.fill(x2 - 2, y1, x2, y2, 0xFF555555);               // right shadow

        // static logo (no animation), centered near top
        int lw = 188, lh = lw * LOGO_H / LOGO_W;
        int lx = panelX + (panelW - lw) / 2, ly = panelY + 8;
        ctx.drawTexture(LOGO, lx, ly, lw, lh, 0, 0, LOGO_W, LOGO_H, LOGO_W, LOGO_H);

        super.render(ctx, mouseX, mouseY, delta);
    }

    @Override
    public boolean shouldPause() { return false; }
}
