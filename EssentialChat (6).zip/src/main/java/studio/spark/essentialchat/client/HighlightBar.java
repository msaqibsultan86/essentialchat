package studio.spark.essentialchat.client;

import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.text.Text;

/** A lightweight fading "mention" bar drawn near the top of the screen. */
public class HighlightBar {

    private static long shownAt = -100000L;
    private static String label = "";
    private static final long DURATION = 3000L; // ms visible

    public static void register() {
        HudRenderCallback.EVENT.register(HighlightBar::onRender);
    }

    public static void show(String text) {
        label = text;
        shownAt = System.currentTimeMillis();
    }

    private static void onRender(DrawContext ctx, RenderTickCounter tick) {
        long life = System.currentTimeMillis() - shownAt;
        if (life > DURATION) return;

        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.options.hudHidden) return;

        // fade out over the last 600ms
        float alpha = 1f;
        long fadeStart = DURATION - 600L;
        if (life > fadeStart) alpha = 1f - (life - fadeStart) / 600f;
        alpha = Math.max(0f, Math.min(1f, alpha));
        int a = (int) (alpha * 255) << 24;

        var tr = mc.textRenderer;
        int sw = ctx.getScaledWindowWidth();
        int barW = 160, barH = 16;
        int bx = (sw - barW) / 2;
        int by = 24;

        ctx.fill(bx, by, bx + barW, by + barH, (a & 0xFF000000) | 0x000A1830);
        // blue progress-style fill shrinking over time
        float prog = 1f - Math.min(1f, (float) life / DURATION);
        ctx.fill(bx, by, bx + (int) (barW * prog), by + barH, (a & 0xFF000000) | 0x002E86F0);
        // border
        int c = (a & 0xFF000000) | 0x003BA9FF;
        ctx.fill(bx, by, bx + barW, by + 1, c);
        ctx.fill(bx, by + barH - 1, bx + barW, by + barH, c);
        ctx.fill(bx, by, bx + 1, by + barH, c);
        ctx.fill(bx + barW - 1, by, bx + barW, by + barH, c);

        int textColor = (a == 0) ? 0x00FFFFFF : (a | 0x00FFFFFF);
        int tw = tr.getWidth(Text.literal(label));
        ctx.drawTextWithShadow(tr, Text.literal(label), bx + (barW - tw) / 2, by + 4, textColor);
    }
}
