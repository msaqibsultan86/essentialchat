package studio.spark.essentialchat.client;

import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

public class HudOverlay {

    private static final SimpleDateFormat CLOCK = new SimpleDateFormat("HH:mm:ss");

    // ---- icons (add more here as you supply them) ----
    private static final Identifier ICON_GLOBE =
            Identifier.of("essentialchat", "textures/gui/icons/globe.png");
    private static final Identifier ICON_PING =
            Identifier.of("essentialchat", "textures/gui/icons/ping.png");
    private static final Identifier ICON_MCCLOCK =
            Identifier.of("essentialchat", "textures/gui/icons/mcclock.png");
    private static final Identifier ICON_BIOME =
            Identifier.of("essentialchat", "textures/gui/icons/biome.png");
    private static final Identifier ICON_REALCLOCK =
            Identifier.of("essentialchat", "textures/gui/icons/realclock.png");
    private static final Identifier ICON_FPS =
            Identifier.of("essentialchat", "textures/gui/icons/fps.png");

    public static void register() {
        HudRenderCallback.EVENT.register(HudOverlay::onRender);
    }

    private static void onRender(DrawContext ctx, RenderTickCounter tick) {
        MinecraftClient mc = MinecraftClient.getInstance();
        EssentialConfig cfg = EssentialChatClient.config;
        if (cfg == null || !cfg.hudEnabled) return;
        if (mc.player == null || mc.options.hudHidden) return;

        var tr = mc.textRenderer;
        List<Identifier> icons = new ArrayList<>();
        List<String> texts = new ArrayList<>();

        if (cfg.showClock) { icons.add(ICON_REALCLOCK); texts.add("§f" + CLOCK.format(new Date())); }

        if (cfg.showGameTime && mc.world != null) {
            long t = mc.world.getTimeOfDay() % 24000L;
            int hour = (int) (((t / 1000) + 6) % 24);
            int min = (int) ((t % 1000) * 60 / 1000);
            icons.add(ICON_MCCLOCK); texts.add(String.format("§f%02d:%02d §7%s", hour, min, phase((int) t)));
        }
        if (cfg.showFps) {
            int fps = mc.getCurrentFps();
            icons.add(ICON_FPS); texts.add("§7FPS: " + fpsColor(fps) + fps);
        }
        if (cfg.showCoords) {
            icons.add(ICON_GLOBE);   // globe icon on coords
            texts.add(String.format("§fx: §b%.0f§f, z: §b%.0f§f, y: §b%.0f",
                    mc.player.getX(), mc.player.getZ(), mc.player.getY()));
        }
        if (cfg.showBiome && mc.world != null) {
            String biome = biomeName(mc);
            if (!biome.isEmpty()) { icons.add(ICON_BIOME); texts.add("§7" + biome); }
        }
        if (cfg.showPing) {
            int ping = 0;
            if (mc.getNetworkHandler() != null) {
                PlayerListEntry e = mc.getNetworkHandler().getPlayerListEntry(mc.player.getUuid());
                if (e != null) ping = e.getLatency();
            }
            icons.add(ICON_PING); texts.add("§7Ping: " + pingColor(ping) + ping + " ms");
        }
        if (texts.isEmpty()) return;

        int pad = 5, lineH = 12, iconCol = 12, iconSz = 9;
        int maxW = 0;
        for (String s : texts) maxW = Math.max(maxW, tr.getWidth(s));

        int bx = 4, by = 4;
        int bw = iconCol + maxW + pad * 2;
        int bh = texts.size() * lineH + pad * 2 - 2;

        ctx.fill(bx, by, bx + bw, by + bh, 0x90000000);
        ctx.fill(bx, by, bx + 2, by + bh, 0xFF3BA9FF);

        int ty = by + pad;
        int textX = bx + pad + iconCol;
        for (int i = 0; i < texts.size(); i++) {
            Identifier ic = icons.get(i);
            if (ic != null) {
                ctx.drawTexture(ic, bx + pad, ty - 1, iconSz, iconSz, 0, 0, 32, 32, 32, 32);
            }
            ctx.drawTextWithShadow(tr, Text.literal(texts.get(i)), textX, ty, 0xFFFFFFFF);
            ty += lineH;
        }
    }

    private static String phase(int t) {
        if (t < 12000) return "Daytime";
        if (t < 13800) return "Sunset";
        if (t < 22200) return "Night";
        return "Sunrise";
    }

    private static String biomeName(MinecraftClient mc) {
        try {
            var entry = mc.world.getBiome(mc.player.getBlockPos());
            Optional<?> keyOpt = entry.getKey();
            if (keyOpt.isPresent()) {
                String path = keyOpt.get().toString();
                int idx = path.lastIndexOf('/');
                if (idx >= 0) path = path.substring(idx + 1);
                path = path.replace("]", "");
                return pretty(path);
            }
        } catch (Exception ignored) {}
        return "";
    }

    private static String pretty(String s) {
        String[] parts = s.split("_");
        StringBuilder b = new StringBuilder();
        for (String p : parts) {
            if (p.isEmpty()) continue;
            b.append(Character.toUpperCase(p.charAt(0))).append(p.substring(1)).append(" ");
        }
        return b.toString().trim();
    }

    private static String fpsColor(int fps) { return fps >= 60 ? "§a" : fps >= 30 ? "§e" : "§c"; }
    private static String pingColor(int p) { return p <= 0 ? "§7" : p < 60 ? "§a" : p < 150 ? "§e" : "§c"; }
}
